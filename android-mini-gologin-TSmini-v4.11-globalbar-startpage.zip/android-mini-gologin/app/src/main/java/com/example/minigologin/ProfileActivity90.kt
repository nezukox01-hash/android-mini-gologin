package com.example.minigologin

class ProfileActivity90 : BaseProfileActivity()
