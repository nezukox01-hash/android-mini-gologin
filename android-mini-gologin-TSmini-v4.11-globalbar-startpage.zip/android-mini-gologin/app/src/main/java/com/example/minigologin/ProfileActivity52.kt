package com.example.minigologin

class ProfileActivity52 : BaseProfileActivity()
