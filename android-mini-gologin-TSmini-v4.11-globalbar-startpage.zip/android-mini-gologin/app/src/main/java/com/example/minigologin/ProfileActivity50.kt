package com.example.minigologin

class ProfileActivity50 : BaseProfileActivity()
