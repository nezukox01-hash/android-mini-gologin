package com.example.minigologin

class ProfileActivity70 : BaseProfileActivity()
