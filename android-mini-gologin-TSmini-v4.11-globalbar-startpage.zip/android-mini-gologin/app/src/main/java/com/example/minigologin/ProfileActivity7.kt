package com.example.minigologin

class ProfileActivity7 : BaseProfileActivity()
