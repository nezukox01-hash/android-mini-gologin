package com.example.minigologin

import android.os.Bundle
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.graphics.Rect
import android.view.View
import android.view.Menu
import android.view.MenuItem
import android.view.inputmethod.EditorInfo
import android.text.InputType
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.doOnLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatEditText
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.viewpager2.widget.ViewPager2
import androidx.activity.OnBackPressedCallback
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.card.MaterialCardView
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

open class BaseProfileActivity : AppCompatActivity() {

    private lateinit var toolbar: MaterialToolbar
    private lateinit var tabLayout: TabLayout
    private lateinit var viewPager: ViewPager2
    private lateinit var urlBox: AppCompatEditText
    private lateinit var profileBtn: ImageButton

    private var currentUserAgent: String = ""
    private var currentAcceptLanguage: String = ""

    private lateinit var adapter: TabsAdapter
    private val tabs = mutableListOf<WebTabFragment>()

    // Listen for global Text-only toggle changes (applies to all profiles/tabs)
    private val textOnlyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val enabled = AppSettingsStore.isTextOnlyEnabled(this@BaseProfileActivity)
            tabs.forEach { it.setTextOnlyEnabled(enabled) }
        }
    }

    private val profileId: Int by lazy {
        // IMPORTANT:
        // Always prefer an explicit profile id passed via Intent extras.
        // This prevents "Profile 2" from behaving like a different profile when opened from different entry points.
        intent.getIntExtra("profile_id",
            intent.getIntExtra("profile",
                Regex("ProfileActivity(\\d+)")
                    .find(this::class.java.simpleName)
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.toIntOrNull()
                    ?: 1
            )
        ).coerceIn(1, 100)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // HARD BLOCK system Back (including edge gestures) inside the browsing screen.
        // This prevents accidental Back while scrolling on aggressive gesture-navigation devices.
        // Use the floating Back button (bottom) for navigation.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Intentionally ignored.
            }
        })

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        tabLayout = findViewById(R.id.tabLayout)
        viewPager = findViewById(R.id.viewPager)
        urlBox = findViewById(R.id.urlBox)
        profileBtn = findViewById(R.id.profileBtn)
        val fabBack = findViewById<View>(R.id.fabBack)

        // Place back button based on global setting (left/right, bottom/middle)
        applyBackFabPosition(fabBack)

        // Reliable back navigation (avoids accidental system-gesture back while scrolling)
        fabBack.setOnClickListener {
            val wv = currentWebView()
            if (wv != null && wv.canGoBack()) {
                wv.goBack()
            } else {
                // No page history → exit profile screen
                finish()
            }
        }

        // Long-press = exit profile screen
        fabBack.setOnLongClickListener {
            finish()
            true
        }

        // Block system back-swipe gestures inside the browser area.
        // We provide our own reliable back button to avoid accidental backs while scrolling.
        viewPager.doOnLayout {
            val w = viewPager.width
            val h = viewPager.height
            if (w > 0 && h > 0) {
                viewPager.systemGestureExclusionRects = listOf(Rect(0, 0, w, h))
            }
        }

        // Title uses saved profile name if present
        val title = ProfileStore.getProfileName(this, profileId) ?: "Profile $profileId"
        supportActionBar?.title = title

        // Per-profile settings (UA / Accept-Language)
        currentUserAgent = ProfileSettingsStore.getUserAgent(this, profileId)
        currentAcceptLanguage = ProfileSettingsStore.getAcceptLanguage(this, profileId)

        val startUrl = intent.getStringExtra("url") ?: intent.getStringExtra("start_url") ?: AppSettingsStore.getStartUrl(this)
        tabs.add(WebTabFragment.newInstance(normalizeUrl(startUrl), currentUserAgent, currentAcceptLanguage))

        adapter = TabsAdapter(this, tabs)
        viewPager.adapter = adapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = "Tab ${position + 1}"
        }.attach()

        // Sync URL bar when switching tabs
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                urlBox.setText(currentWebView()?.url ?: "")
            }
        })

        // Navigate from URL bar
        urlBox.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                val u = normalizeUrl(urlBox.text?.toString() ?: "")
                if (u.isNotBlank()) {
                    loadUrl(u)
                }
                true
            } else false
        }

        // Quick profile switch (small round button)
        profileBtn.setOnClickListener { showProfilePicker() }
    }

    private fun applyBackFabPosition(fabBack: View) {
        val root = fabBack.parent
        if (root !is ConstraintLayout) return

        val pos = AppSettingsStore.getBackButtonPos(this)
        val set = ConstraintSet()
        set.clone(root)

        // Clear existing constraints first
        set.clear(fabBack.id, ConstraintSet.START)
        set.clear(fabBack.id, ConstraintSet.END)
        set.clear(fabBack.id, ConstraintSet.TOP)
        set.clear(fabBack.id, ConstraintSet.BOTTOM)

        // Always keep a small margin
        val margin = (16 * resources.displayMetrics.density).toInt()
        val vMargin = (18 * resources.displayMetrics.density).toInt()

        when (pos) {
            "bottom_right" -> {
                set.connect(fabBack.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END, margin)
                set.connect(fabBack.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, vMargin)
            }
            "middle_left" -> {
                set.connect(fabBack.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START, margin)
                set.connect(fabBack.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP, 0)
                set.connect(fabBack.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, 0)
                set.setVerticalBias(fabBack.id, 0.5f)
            }
            "middle_right" -> {
                set.connect(fabBack.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END, margin)
                set.connect(fabBack.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP, 0)
                set.connect(fabBack.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, 0)
                set.setVerticalBias(fabBack.id, 0.5f)
            }
            else -> { // bottom_left
                set.connect(fabBack.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START, margin)
                set.connect(fabBack.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, vMargin)
            }
        }

        set.applyTo(root)
    }

    override fun onStart() {
        super.onStart()
        registerReceiver(textOnlyReceiver, IntentFilter(AppSettingsStore.ACTION_TEXT_ONLY_CHANGED))
    }

    override fun onStop() {
        try {
            unregisterReceiver(textOnlyReceiver)
        } catch (_: Throwable) {
        }
        super.onStop()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.profile_tabs_menu, menu)
        menuInflater.inflate(R.menu.profile_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_new_tab -> { addNewTab(); true }
            R.id.action_close_tab -> { closeCurrentTab(); true }
            R.id.action_refresh -> { currentWebView()?.reload(); true }
            R.id.action_home -> { loadUrl("https://m.facebook.com"); true }

            R.id.action_app_home -> {
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                finish()
                true
            }
            R.id.action_profile_home -> { loadUrl("https://m.facebook.com"); true }
            R.id.action_profiles -> { showProfilePicker(); true }
            R.id.action_profile_settings -> { showProfileSettings(); true }
            R.id.action_add_bookmark -> { addBookmarkForCurrentTab(); true }
            R.id.action_bookmarks -> { showBookmarks(); true }
            R.id.action_reload -> { currentWebView()?.reload(); true }
            R.id.action_clear_profile_data -> { clearThisProfileData(); true }
            R.id.action_rename_profile -> { renameProfile(); true }
            R.id.action_open_external -> { openInBrowser(); true }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun currentWebView(): WebView? {
        val idx = viewPager.currentItem.coerceIn(0, tabs.size - 1)
        return tabs.getOrNull(idx)?.getWebViewOrNull()
    }

    
private fun buildHeaders(): Map<String, String> {
    val lang = currentAcceptLanguage.trim()
    return if (lang.isBlank()) emptyMap() else mapOf("Accept-Language" to lang)
}

fun addNewTab(url: String? = null) {
        tabs.add(WebTabFragment.newInstance(normalizeUrl(url ?: AppSettingsStore.getStartUrl(this)), currentUserAgent, currentAcceptLanguage))
        adapter.notifyItemInserted(tabs.size - 1)
        viewPager.setCurrentItem(tabs.size - 1, true)
        Snackbar.make(findViewById(android.R.id.content), "New tab opened", Snackbar.LENGTH_SHORT).show()
    }

    private fun closeCurrentTab() {
        val idx = tabLayout.selectedTabPosition.takeIf { it >= 0 } ?: viewPager.currentItem
        if (tabs.size <= 1) {
            Toast.makeText(this, "Can't close the last tab", Toast.LENGTH_SHORT).show()
            return
        }
        if (idx < 0 || idx >= tabs.size) return

        tabs.removeAt(idx)
        adapter.notifyItemRemoved(idx)

        val newIdx = (idx - 1).coerceAtLeast(0).coerceAtMost(tabs.size - 1)
        viewPager.setCurrentItem(newIdx, false)
        updateUrlBox()
    }

    private fun updateUrlBox() {
        urlBox.setText(currentWebView()?.url ?: "")
    }

    private fun loadUrl(input: String) {
    val t = input.trim()
    if (t.startsWith("javascript:", ignoreCase = true)) {
        executeBookmark(t)
        return
    }
    val url = normalizeUrl(t)
    val hdrs = buildHeaders()
    if (hdrs.isEmpty()) currentWebView()?.loadUrl(url) else currentWebView()?.loadUrl(url, hdrs)
    urlBox.setText(url)
}


private fun executeBookmark(raw: String) {
    val trimmed = raw.trim()
    if (trimmed.isEmpty()) return
    val wv = currentWebView() ?: return

    // Run bookmarklets directly in the current tab
    if (trimmed.startsWith("javascript:", ignoreCase = true)) {
        val js = trimmed.removePrefix("javascript:")
        wv.evaluateJavascript(js, null)
        Toast.makeText(this, "Script executed", Toast.LENGTH_SHORT).show()
        return
    }

    // Normal URL
    val url = normalizeUrl(trimmed)
    wv.loadUrl(url)
    urlBox.setText(url)
}

    private fun normalizeUrl(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return "https://m.facebook.com"
        return when {
            trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true) -> trimmed
            else -> "https://$trimmed"
        }
    }

    
private fun showProfileSettings() {
    val container = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val pad = (16 * resources.displayMetrics.density).toInt()
        setPadding(pad, pad, pad, pad)
    }

    val uaBox = AppCompatEditText(this).apply {
        hint = "User-Agent (leave empty = default)"
        setText(currentUserAgent)
        inputType = InputType.TYPE_CLASS_TEXT
    }
    val langBox = AppCompatEditText(this).apply {
        hint = "Accept-Language (e.g., en-US,en;q=0.9 or bn-BD,bn;q=0.9)"
        setText(currentAcceptLanguage)
        inputType = InputType.TYPE_CLASS_TEXT
    }

    container.addView(uaBox)
    container.addView(langBox)

    AlertDialog.Builder(this)
        .setTitle("Profile settings (Profile $profileId)")
        .setView(container)
        .setNeutralButton("Reset") { _, _ ->
            ProfileSettingsStore.clear(this, profileId)
            currentUserAgent = ""
            currentAcceptLanguage = ""
            Toast.makeText(this, "Reset settings. Reopen tabs to apply.", Toast.LENGTH_SHORT).show()
        }
        .setNegativeButton("Cancel", null)
        .setPositiveButton("Save") { _, _ ->
            currentUserAgent = uaBox.text?.toString().orEmpty().trim()
            currentAcceptLanguage = langBox.text?.toString().orEmpty().trim()
            ProfileSettingsStore.setUserAgent(this, profileId, currentUserAgent)
            ProfileSettingsStore.setAcceptLanguage(this, profileId, currentAcceptLanguage)
            Toast.makeText(this, "Saved. New tabs will use updated settings.", Toast.LENGTH_SHORT).show()
        }
        .show()
}

private fun showProfilePicker() {
    val currentMax = ProfileStore.getMaxProfiles(this).coerceAtMost(100)
    val items = (1..currentMax).map { i ->
        val name = ProfileStore.getProfileName(this, i) ?: "Profile $i"
        CardRow(title = name, subtitle = "#${i}")
    }.toMutableList()

    val addIndex = if (currentMax < 100) {
        items.add(CardRow(title = "Add profile", subtitle = "Create new", isAddAction = true))
        items.lastIndex
    } else -1

    showCardListDialog(
        title = "Switch profile",
        rows = items,
        onClick = { index ->
            if (index == addIndex) {
                val next = (currentMax + 1).coerceAtMost(100)
                ProfileStore.setMaxProfiles(this, next)
                Toast.makeText(this, "Created Profile $next", Toast.LENGTH_SHORT).show()
                val cls = Class.forName("${packageName}.ProfileActivity$next")
                startActivity(Intent(this, cls).putExtra("profile_id", next))
                finish()
                return@showCardListDialog
            }

            val targetId = index + 1
            if (targetId == profileId) return@showCardListDialog
            val cls = Class.forName("${packageName}.ProfileActivity$targetId")
            startActivity(Intent(this, cls).putExtra("profile_id", targetId))
            finish()
        },
        onLongClick = { index ->
            // Long-press a profile row to rename
            if (index == addIndex) return@showCardListDialog
            val pid = index + 1
            showRenameProfileDialog(pid)
        }
    )
}


    private fun addBookmarkForCurrentTab() {
        val wv = currentWebView()
        val url = wv?.url
        if (url.isNullOrBlank()) {
            Toast.makeText(this, "No page to bookmark", Toast.LENGTH_SHORT).show()
            return
        }
        val title = (wv?.title?.takeIf { it.isNotBlank() } ?: url)
        BookmarkStore.add(applicationContext, title, url)
        Toast.makeText(this, "Bookmark added", Toast.LENGTH_SHORT).show()
    }

    private fun showBookmarks() {
        val list = BookmarkStore.getAll(applicationContext)
        if (list.isEmpty()) {
            Toast.makeText(this, "No bookmarks yet", Toast.LENGTH_SHORT).show()
            return
        }

        // Keep insertion order (first added stays at top)
        val rows = list.map { b ->
            CardRow(title = b.title, subtitle = b.url)
        }

        showCardListDialog(
            title = "Bookmarks",
            rows = rows,
            onClick = { index ->
                // Single tap = open (no extra confirmation)
                val b = list[index]
                loadUrl(b.url)
            },
            onLongClick = { index ->
                val b = list[index]
                // Long press = edit/delete
                AlertDialog.Builder(this)
                    .setTitle(b.title)
                    .setItems(arrayOf("Edit", "Delete")) { _, action ->
                        when (action) {
                            0 -> showEditBookmarkDialog(index, b.title, b.url)
                            1 -> {
                                BookmarkStore.deleteAt(applicationContext, index)
                                Toast.makeText(this, "Bookmark deleted", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )
    }

    // ---------- Card list dialog (Profiles + Bookmarks) ----------
    private data class CardRow(
        val title: String,
        val subtitle: String = "",
        val isAddAction: Boolean = false
    )

    private fun accentColorForIndex(i: Int): Int {
        // 1 pink, 2 purple, 3 yellow pattern repeating
        val colors = intArrayOf(
            0xFFFF4DA6.toInt(), // pink
            0xFF7C4DFF.toInt(), // purple
            0xFFFFC107.toInt()  // yellow
        )
        return colors[i % 3]
    }

    private fun showCardListDialog(
        title: String,
        rows: List<CardRow>,
        onClick: (index: Int) -> Unit,
        onLongClick: (index: Int) -> Unit
    ) {
        val view = layoutInflater.inflate(R.layout.dialog_list_cards, null)
        val listView = view.findViewById<ListView>(R.id.listView)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount(): Int = rows.size
            override fun getItem(position: Int): Any = rows[position]
            override fun getItemId(position: Int): Long = position.toLong()

            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val v = convertView ?: layoutInflater.inflate(R.layout.item_card_row, parent, false)
                val accent = v.findViewById<View>(R.id.accentStrip)
                val titleTv = v.findViewById<TextView>(R.id.titleText)
                val subTv = v.findViewById<TextView>(R.id.subText)
                val card = v.findViewById<MaterialCardView>(R.id.cardRoot)

                accent.setBackgroundColor(accentColorForIndex(position))
                val r = rows[position]
                titleTv.text = r.title
                subTv.text = r.subtitle
                subTv.visibility = if (r.subtitle.isBlank()) View.GONE else View.VISIBLE

                // Slightly different look for add action
                card.alpha = if (r.isAddAction) 0.95f else 1.0f

                return v
            }
        }

        listView.adapter = adapter

        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton("Close", null)
            .create()

        listView.setOnItemClickListener { _, _, position, _ ->
            dialog.dismiss()
            onClick(position)
        }
        listView.setOnItemLongClickListener { _, _, position, _ ->
            dialog.dismiss()
            onLongClick(position)
            true
        }

        dialog.show()
    }

    private fun showRenameProfileDialog(targetProfileId: Int) {
        val input = AppCompatEditText(this).apply {
            setText(ProfileStore.getProfileName(this@BaseProfileActivity, targetProfileId) ?: "")
            hint = "Profile name"
        }
        AlertDialog.Builder(this)
            .setTitle("Rename Profile $targetProfileId")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text?.toString()?.trim().orEmpty()
                if (name.isBlank()) {
                    ProfileStore.clearProfileName(this, targetProfileId)
                } else {
                    ProfileStore.setProfileName(this, targetProfileId, name)
                }
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditBookmarkDialog(index: Int, oldTitle: String, oldUrl: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }

        val titleInput = AppCompatEditText(this).apply {
            hint = "Name"
            setText(oldTitle)
        }
        val urlInput = AppCompatEditText(this).apply {
            hint = "URL"
            setText(oldUrl)
        }

        box.addView(titleInput)
        box.addView(urlInput)

        AlertDialog.Builder(this)
            .setTitle("Edit bookmark")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val nt = titleInput.text?.toString() ?: ""
                val nu = urlInput.text?.toString() ?: ""
                if (nu.isBlank()) {
                    Toast.makeText(this, "URL can't be empty", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                BookmarkStore.updateAt(applicationContext, index, nt, nu)
                Toast.makeText(this, "Bookmark updated", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun clearThisProfileData() {
        // Best-effort clearing for the current WebView process/profile
        currentWebView()?.apply {
            clearHistory()
            clearCache(true)
            clearFormData()
        }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()

        Toast.makeText(this, "Cleared this profile data", Toast.LENGTH_SHORT).show()
        loadUrl("https://m.facebook.com")
    }

    private fun renameProfile() {
        val input = AppCompatEditText(this).apply {
            setText(ProfileStore.getProfileName(this@BaseProfileActivity, profileId) ?: "")
            hint = "Profile name"
        }
        AlertDialog.Builder(this)
            .setTitle("Rename profile")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text?.toString()?.trim().orEmpty()
                if (name.isBlank()) {
                    ProfileStore.clearProfileName(this, profileId)
                    supportActionBar?.title = "Profile $profileId"
                } else {
                    ProfileStore.setProfileName(this, profileId, name)
                    supportActionBar?.title = name
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openInBrowser() {
        val url = currentWebView()?.url ?: return
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }.onFailure {
            Toast.makeText(this, "Can't open browser", Toast.LENGTH_SHORT).show()
        }
    }


    // normalizeUrl() is defined earlier in this file.
}
