package com.example.minigologin

class ProfileActivity100 : BaseProfileActivity()
