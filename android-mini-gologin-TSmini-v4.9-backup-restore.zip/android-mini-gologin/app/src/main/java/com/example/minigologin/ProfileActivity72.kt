package com.example.minigologin

class ProfileActivity72 : BaseProfileActivity()
