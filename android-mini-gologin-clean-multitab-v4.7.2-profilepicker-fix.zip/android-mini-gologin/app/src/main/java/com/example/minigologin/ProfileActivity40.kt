package com.example.minigologin

class ProfileActivity40 : BaseProfileActivity()
