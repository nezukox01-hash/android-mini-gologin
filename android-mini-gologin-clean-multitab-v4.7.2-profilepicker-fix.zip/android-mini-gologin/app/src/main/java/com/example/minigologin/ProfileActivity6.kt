package com.example.minigologin

class ProfileActivity6 : BaseProfileActivity()
