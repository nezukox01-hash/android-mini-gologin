package com.example.minigologin

class ProfileActivity32 : BaseProfileActivity()
