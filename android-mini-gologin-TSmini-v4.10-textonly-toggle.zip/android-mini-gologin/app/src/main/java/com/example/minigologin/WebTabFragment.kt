package com.example.minigologin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.io.ByteArrayInputStream
import java.util.Locale

class WebTabFragment : Fragment() {

    private var webView: WebView? = null

    private fun headers(): Map<String, String> {
        val lang = arguments?.getString("accept_lang")?.trim().orEmpty()
        return if (lang.isBlank()) emptyMap() else mapOf("Accept-Language" to lang)
    }

    private fun applyUserAgent(wv: WebView) {
        val ua = arguments?.getString("user_agent")?.trim().orEmpty()
        if (ua.isNotBlank()) {
            wv.settings.userAgentString = ua
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val ctx = requireContext()

        val swipeLayout = SwipeRefreshLayout(ctx)
        val wv = WebView(ctx)

        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true

        applyUserAgent(wv)

        // Apply global "text-only" rule (experimental)
        applyTextOnlyToWebView(wv, AppSettingsStore.isTextOnlyEnabled(ctx))

        // Needed for alert(), confirm(), prompt()
        wv.webChromeClient = WebChromeClient()

        val hdrs = headers()

        wv.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (!request.isForMainFrame) return false
                // Let javascript: urls run normally
                if (url.startsWith("javascript:", ignoreCase = true)) return false
                view?.loadUrl(url, hdrs)
                return true
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                val u = url ?: return false
                if (u.startsWith("javascript:", ignoreCase = true)) return false
                view?.loadUrl(u, hdrs)
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                swipeLayout.isRefreshing = false
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val ctx = view?.context ?: return null
                if (!AppSettingsStore.isTextOnlyEnabled(ctx)) return null

                val u = request?.url?.toString() ?: return null
                if (shouldBlockAsMedia(u)) {
                    // Empty response => resource is not downloaded.
                    return WebResourceResponse(
                        "text/plain",
                        "utf-8",
                        ByteArrayInputStream(ByteArray(0))
                    )
                }
                return null
            }
        }

        swipeLayout.setOnRefreshListener { wv.reload() }
        swipeLayout.setOnChildScrollUpCallback { _, _ -> wv.scrollY > 0 }

        swipeLayout.addView(
            wv,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val url = arguments?.getString("url") ?: "https://www.google.com"
        if (hdrs.isEmpty()) {
            wv.loadUrl(url)
        } else {
            wv.loadUrl(url, hdrs)
        }

        webView = wv
        return swipeLayout
    }

    override fun onDestroyView() {
        super.onDestroyView()
        webView = null
    }

    fun getWebViewOrNull(): WebView? = webView

    fun setTextOnlyEnabled(enabled: Boolean) {
        val wv = webView ?: return
        applyTextOnlyToWebView(wv, enabled)
        try { wv.reload() } catch (_: Throwable) {}
    }

    private fun applyTextOnlyToWebView(wv: WebView, enabled: Boolean) {
        // Best-effort: block images without breaking JS/CSS.
        wv.settings.loadsImagesAutomatically = !enabled
        wv.settings.blockNetworkImage = enabled
    }

    private fun shouldBlockAsMedia(url: String): Boolean {
        val u = url.lowercase(Locale.ROOT)
        // Images
        if (u.endsWith(".png") || u.endsWith(".jpg") || u.endsWith(".jpeg") || u.endsWith(".gif") ||
            u.endsWith(".webp") || u.endsWith(".bmp") || u.endsWith(".svg")) return true
        // Video / audio
        if (u.endsWith(".mp4") || u.endsWith(".webm") || u.endsWith(".mkv") || u.endsWith(".mov") ||
            u.endsWith(".m3u8") || u.endsWith(".mp3") || u.endsWith(".aac") || u.endsWith(".wav") ||
            u.endsWith(".ogg") || u.endsWith(".flac")) return true
        return false
    }

    companion object {
        fun newInstance(url: String, userAgent: String = "", acceptLanguage: String = ""): WebTabFragment {
            val fragment = WebTabFragment()
            val args = Bundle()
            args.putString("url", url)
            args.putString("user_agent", userAgent)
            args.putString("accept_lang", acceptLanguage)
            fragment.arguments = args
            return fragment
        }
    }
}
