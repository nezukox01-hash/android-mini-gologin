package com.example.minigologin

class ProfileActivity27 : BaseProfileActivity()
