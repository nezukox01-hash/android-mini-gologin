package com.example.minigologin

class ProfileActivity65 : BaseProfileActivity()
