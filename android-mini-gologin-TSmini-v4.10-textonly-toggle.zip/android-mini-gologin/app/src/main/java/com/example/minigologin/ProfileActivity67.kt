package com.example.minigologin

class ProfileActivity67 : BaseProfileActivity()
