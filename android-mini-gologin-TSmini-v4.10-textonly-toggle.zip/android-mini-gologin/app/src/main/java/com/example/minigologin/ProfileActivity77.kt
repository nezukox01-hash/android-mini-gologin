package com.example.minigologin

class ProfileActivity77 : BaseProfileActivity()
