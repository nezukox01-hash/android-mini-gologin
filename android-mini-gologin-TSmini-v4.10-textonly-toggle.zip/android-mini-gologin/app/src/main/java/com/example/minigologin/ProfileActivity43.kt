package com.example.minigologin

class ProfileActivity43 : BaseProfileActivity()
