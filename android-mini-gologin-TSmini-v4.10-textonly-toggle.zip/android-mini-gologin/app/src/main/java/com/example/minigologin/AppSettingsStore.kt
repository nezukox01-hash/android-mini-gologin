package com.example.minigologin

import android.content.Context
import android.content.Intent

/** App-wide settings (apply to all profiles/tabs). */
object AppSettingsStore {
    private const val PREFS = "app_settings"
    private const val KEY_TEXT_ONLY = "text_only"

    const val ACTION_TEXT_ONLY_CHANGED = "com.example.minigologin.TEXT_ONLY_CHANGED"

    fun isTextOnlyEnabled(ctx: Context): Boolean {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_TEXT_ONLY, false)
    }

    fun setTextOnlyEnabled(ctx: Context, enabled: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_TEXT_ONLY, enabled)
            .apply()
    }

    fun broadcastTextOnlyChanged(ctx: Context) {
        ctx.sendBroadcast(Intent(ACTION_TEXT_ONLY_CHANGED))
    }
}
