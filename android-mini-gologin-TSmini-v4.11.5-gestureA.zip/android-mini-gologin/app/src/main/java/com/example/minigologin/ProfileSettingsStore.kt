package com.example.minigologin

import android.content.Context

object ProfileSettingsStore {
    private const val PREFS = "profile_settings"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getUserAgent(ctx: Context, profileId: Int): String =
        prefs(ctx).getString("ua_$profileId", "") ?: ""

    fun setUserAgent(ctx: Context, profileId: Int, ua: String) {
        prefs(ctx).edit().putString("ua_$profileId", ua.trim()).apply()
    }

    fun getAcceptLanguage(ctx: Context, profileId: Int): String =
        prefs(ctx).getString("lang_$profileId", "") ?: ""

    fun setAcceptLanguage(ctx: Context, profileId: Int, lang: String) {
        prefs(ctx).edit().putString("lang_$profileId", lang.trim()).apply()
    }

    fun clear(ctx: Context, profileId: Int) {
        prefs(ctx).edit()
            .remove("ua_$profileId")
            .remove("lang_$profileId")
            .apply()
    }
}
