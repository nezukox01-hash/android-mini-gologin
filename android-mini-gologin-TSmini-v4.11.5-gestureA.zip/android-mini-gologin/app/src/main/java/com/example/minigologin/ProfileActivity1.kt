package com.example.minigologin

class ProfileActivity1 : BaseProfileActivity()
