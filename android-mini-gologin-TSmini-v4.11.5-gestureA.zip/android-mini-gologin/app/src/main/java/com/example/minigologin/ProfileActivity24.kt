package com.example.minigologin

class ProfileActivity24 : BaseProfileActivity()
