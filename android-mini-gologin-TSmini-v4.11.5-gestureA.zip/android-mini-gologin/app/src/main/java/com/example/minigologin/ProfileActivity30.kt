package com.example.minigologin

class ProfileActivity30 : BaseProfileActivity()
