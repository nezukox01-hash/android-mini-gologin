package com.example.minigologin

class ProfileActivity28 : BaseProfileActivity()
