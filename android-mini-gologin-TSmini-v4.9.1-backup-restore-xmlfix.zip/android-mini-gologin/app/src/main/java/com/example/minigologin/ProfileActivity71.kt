package com.example.minigologin

class ProfileActivity71 : BaseProfileActivity()
