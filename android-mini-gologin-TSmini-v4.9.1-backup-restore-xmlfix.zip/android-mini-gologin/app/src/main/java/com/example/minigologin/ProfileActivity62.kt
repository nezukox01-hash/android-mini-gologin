package com.example.minigologin

class ProfileActivity62 : BaseProfileActivity()
