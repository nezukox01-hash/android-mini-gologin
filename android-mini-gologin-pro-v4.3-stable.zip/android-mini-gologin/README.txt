Mini GoLogin Pro (Learning) - Android v4.5 (Settings Backup)

Added:
- Export backup to Downloads (JSON): bookmarks + profile names + theme + max profile count
- Import backup from JSON (pick file; easiest is Downloads)

Notes:
- This does NOT guarantee restoring logged-in sessions for all websites.
  WebView session data lives in internal storage and isn't reliably portable without OS-level backup.
