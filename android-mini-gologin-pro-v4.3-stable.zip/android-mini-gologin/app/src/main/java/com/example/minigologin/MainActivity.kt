package com.example.minigologin

import android.content.Intent
import java.util.Locale
import java.util.Date
import java.text.SimpleDateFormat
import androidx.activity.result.contract.ActivityResultContracts
import android.provider.MediaStore
import android.os.Build
import android.net.Uri
import android.content.ContentValues
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeStore.applySaved(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri == null) return@registerForActivityResult
            try {
                contentResolver.openInputStream(uri)?.use { ins ->
                    val json = ins.bufferedReader().readText()
                    SettingsBackup.importJson(this, json)
                }
                Snackbar.make(findViewById(android.R.id.content), "Imported backup. Restarting…", Snackbar.LENGTH_SHORT).show()
                // Apply theme and refresh UI
                ThemeStore.applySaved(this)
                recreate()
            } catch (e: Exception) {
                Snackbar.make(findViewById(android.R.id.content), "Import failed: ${'$'}{e.message}", Snackbar.LENGTH_LONG).show()
            }
        }

        val urlInput = findViewById<TextInputEditText>(R.id.urlInput)
        val profileInput = findViewById<TextInputEditText>(R.id.profileInput)
        val pickBtn = findViewById<MaterialButton>(R.id.pickProfileBtn)
        val exportBtn = findViewById<MaterialButton>(R.id.exportBtn)
        val importBtn = findViewById<MaterialButton>(R.id.importBtn)
        val openBtn = findViewById<MaterialButton>(R.id.openBtn)

        if (urlInput.text.isNullOrBlank()) {
            urlInput.setText("https://m.facebook.com")
        }

        
pickBtn.setOnClickListener { _ ->
            showProfilePicker { picked ->
                profileInput.setText(picked.toString())
            }
        }

exportBtn.setOnClickListener { v ->
    try {
        val sdf = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US)
        val name = "mini-gologin-backup-${'$'}{sdf.format(Date())}.json"
        val json = SettingsBackup.exportJson(this)

        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/json")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/")
            }
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Snackbar.make(v, "Export failed: cannot create file", Snackbar.LENGTH_LONG).show()
            return@setOnClickListener
        }
        contentResolver.openOutputStream(uri)?.use { out ->
            out.write(json.toByteArray())
        }
        Snackbar.make(v, "Exported to Downloads: ${'$'}name", Snackbar.LENGTH_LONG).show()
    } catch (e: Exception) {
        Snackbar.make(v, "Export failed: ${'$'}{e.message}", Snackbar.LENGTH_LONG).show()
    }
}

importBtn.setOnClickListener { _ ->
    // User will pick the JSON file (usually from Downloads)
    importLauncher.launch(arrayOf("application/json", "text/*"))
}


        openBtn.setOnClickListener { v ->
            val url = normalizeUrl(urlInput.text?.toString() ?: "")
            val n = profileInput.text?.toString()?.trim()?.toIntOrNull()
            val max = ProfileStore.getMaxProfiles(this)

            if (n == null || n !in 1..max) {
                Snackbar.make(v, "Profile number must be 1–$max", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cls = Class.forName("com.example.minigologin.ProfileActivity$n")
            val intent = Intent(this, cls).apply {
                putExtra("url", url)
                putExtra("profile", n)
            }
            startActivity(intent)
        }
    }


    private fun normalizeUrl(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return "https://m.facebook.com"
        val lower = s.lowercase()
        return if (lower.startsWith("http://") || lower.startsWith("https://")) s
        else "https://$s"
    }

    private fun showProfilePicker(onPick: (Int) -> Unit) {
        val max = ProfileStore.getMaxProfiles(this)
        val names = (1..max).map { i -> ProfileStore.getName(this, i) }.toMutableList()
        names.add("➕ Add profile")
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Select profile")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == max) {
                    val newMax = ProfileStore.addOneProfile(this)
                    Snackbar.make(findViewById(android.R.id.content), "Added profile $newMax", Snackbar.LENGTH_SHORT).show()
                    showProfilePicker(onPick)
                } else {
                    onPick(which + 1)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
