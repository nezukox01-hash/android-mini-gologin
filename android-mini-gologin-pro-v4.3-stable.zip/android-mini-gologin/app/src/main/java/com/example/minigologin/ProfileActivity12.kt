package com.example.minigologin

class ProfileActivity12 : BaseProfileActivity()
