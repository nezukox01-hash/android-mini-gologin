package com.example.minigologin

import android.content.Context
import kotlin.math.max
import kotlin.math.min

object ProfileStore {
    private const val PREF = "mini_gologin"
    private const val KEY_MAX = "max_profiles"
    private fun key(profile: Int) = "profile_name_$profile"

    fun getMaxProfiles(context: Context): Int {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val v = sp.getInt(KEY_MAX, 20)
        return min(100, max(1, v))
    }

    fun setMaxProfiles(context: Context, value: Int) {
        val v = min(100, max(1, value))
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putInt(KEY_MAX, v).apply()
        // ensure names exist up to v
        for (i in 1..v) ensureExists(context, i)
    }

    fun addOneProfile(context: Context): Int {
        val cur = getMaxProfiles(context)
        val next = min(100, cur + 1)
        setMaxProfiles(context, next)
        return next
    }

    fun getName(context: Context, profile: Int): String {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return sp.getString(key(profile), null) ?: "Profile $profile"
    }

    fun ensureExists(context: Context, profile: Int) {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!sp.contains(key(profile))) {
            sp.edit().putString(key(profile), "Profile $profile").apply()
        }
    }

    fun setName(context: Context, profile: Int, name: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(key(profile), name.take(40).ifBlank { "Profile $profile" })
            .apply()
    }
}
