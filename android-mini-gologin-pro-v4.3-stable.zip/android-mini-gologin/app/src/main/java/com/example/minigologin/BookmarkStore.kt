package com.example.minigologin

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Bookmark(val title: String, val url: String, val ts: Long)

object BookmarkStore {
    private const val PREF = "mini_gologin"
    private const val KEY = "bookmarks_global"

    fun list(context: Context): List<Bookmark> {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val raw = sp.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = ArrayList<Bookmark>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(
                Bookmark(
                    title = o.optString("title", "Bookmark"),
                    url = o.optString("url", ""),
                    ts = o.optLong("ts", 0L)
                )
            )
        }
        return out
    }

    fun add(context: Context, title: String, url: String) {
        val list = list(context).toMutableList()
        // Deduplicate by url
        val existingIdx = list.indexOfFirst { it.url == url }
        if (existingIdx >= 0) list.removeAt(existingIdx)
        list.add(0, Bookmark(title.take(80), url, System.currentTimeMillis()))
        save(context, list)
    }

    fun deleteAt(context: Context, index: Int) {
        val list = list(context).toMutableList()
        if (index in list.indices) {
            list.removeAt(index)
            save(context, list)
        }
    }

    private fun save(context: Context, list: List<Bookmark>) {
        val arr = JSONArray()
        for (b in list.take(200)) {
            val o = JSONObject()
            o.put("title", b.title)
            o.put("url", b.url)
            o.put("ts", b.ts)
            arr.put(o)
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, arr.toString())
            .apply()
    }

    fun getAll(ctx: Context): List<Item> = list(ctx)

}
