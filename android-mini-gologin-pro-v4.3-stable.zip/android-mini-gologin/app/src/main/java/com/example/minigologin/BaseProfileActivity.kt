package com.example.minigologin

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatEditText
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

open class BaseProfileActivity : AppCompatActivity() {

    private lateinit var toolbar: MaterialToolbar
    private lateinit var tabLayout: TabLayout
    private lateinit var viewPager: ViewPager2
    private lateinit var urlBox: AppCompatEditText

    private lateinit var adapter: TabsAdapter
    private val tabs = mutableListOf<WebTabFragment>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        tabLayout = findViewById(R.id.tabLayout)
        viewPager = findViewById(R.id.viewPager)
        urlBox = findViewById(R.id.urlBox)

        val startUrl = intent.getStringExtra("url") ?: intent.getStringExtra("start_url") ?: "https://www.google.com"
        tabs.add(WebTabFragment.newInstance(normalizeUrl(startUrl)))

        adapter = TabsAdapter(this, tabs)
        viewPager.adapter = adapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = "Tab ${position + 1}"
        }.attach()

        // Sync URL bar when switching tabs
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                urlBox.setText(currentWebView()?.url ?: "")
            }
        })

        // Navigate from URL bar
        urlBox.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                val u = normalizeUrl(urlBox.text?.toString() ?: "")
                if (u.isNotBlank()) {
                    currentWebView()?.loadUrl(u)
                }
                true
            } else false
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.profile_tabs_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_new_tab -> { addNewTab(); true }
            R.id.action_close_tab -> { closeCurrentTab(); true }
            R.id.action_refresh -> { currentWebView()?.reload(); true }
            R.id.action_home -> { currentWebView()?.loadUrl("https://www.google.com"); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun currentWebView(): WebView? {
        val idx = viewPager.currentItem.coerceIn(0, tabs.size - 1)
        return tabs.getOrNull(idx)?.getWebViewOrNull()
    }

    fun addNewTab(url: String = "https://www.google.com") {
        tabs.add(WebTabFragment.newInstance(normalizeUrl(url)))
        adapter.notifyItemInserted(tabs.size - 1)
        viewPager.setCurrentItem(tabs.size - 1, true)
        Snackbar.make(findViewById(android.R.id.content), "New tab opened", Snackbar.LENGTH_SHORT).show()
    }

    private private fun closeCurrentTab() {
    val idx = tabLayout.selectedTabPosition.takeIf { it >= 0 } ?: viewPager.currentItem
    if (tabs.size <= 1) {
        Toast.makeText(this, "Can't close the last tab", Toast.LENGTH_SHORT).show()
        return
    }
    if (idx < 0 || idx >= tabs.size) return

    tabs.removeAt(idx)
    adapter.notifyItemRemoved(idx)

    val newIdx = (idx - 1).coerceAtLeast(0).coerceAtMost(tabs.size - 1)
    viewPager.setCurrentItem(newIdx, false)
    updateUrlBox()
}


    private fun normalizeUrl(input: String): String {
        val t = input.trim()
        if (t.isBlank()) return ""
        return if (t.startsWith("http://") || t.startsWith("https://")) t
        else "https://$t"
    }
}
