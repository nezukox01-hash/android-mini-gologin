package com.example.minigologin

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.Menu
import android.view.MenuItem
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textview.MaterialTextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import android.app.AlertDialog
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import java.net.URI

abstract class BaseProfileActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var progress: LinearProgressIndicator
    private lateinit var errorOverlay: View
    private lateinit var errorMsg: MaterialTextView
    private var startUrl: String = "https://m.facebook.com"
    private var profileId: Int = -1

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeStore.applySaved(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        profileId = intent.getIntExtra("profile", -1)
        ProfileStore.ensureExists(this, profileId)
        startUrl = intent.getStringExtra("url")?.trim().orEmpty().ifBlank { "https://m.facebook.com" }

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.title = ProfileStore.getName(this, profileId)
        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener { finish() }

        progress = findViewById(R.id.progress)
        errorOverlay = findViewById(R.id.errorOverlay)
        errorMsg = findViewById(R.id.errorMsg)

        val retryBtn = findViewById<MaterialButton>(R.id.retryBtn)
        val openExternalBtn = findViewById<MaterialButton>(R.id.openExternalBtn)

        retryBtn.setOnClickListener { load(startUrl, forceNoCache = true) }
        openExternalBtn.setOnClickListener {
            try {
                openExternal(startUrl)
            } catch (_: Exception) {}
        }

        web = findViewById(R.id.web)
        applyProfileNetworkSettings()

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadsImagesAutomatically = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(true)
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = s.userAgentString + " MiniGoLogin/1.1"

        // Mixed content can be needed on some sites; keep it permissive for learning
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        // Cookies
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true)

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress in 1..99) {
                    progress.visibility = View.VISIBLE
                    progress.progress = newProgress
                } else {
                    progress.visibility = View.GONE
                }
            }
        }

        web.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
    val url = request?.url?.toString() ?: return false
    // Apply optional headers (Accept-Language) for main-frame navigations
    return if (request.isForMainFrame) {
        loadWithHeaders(url)
        true
    } else {
        false
    }
}












override fun onOptionsItemSelected(item: MenuItem): Boolean {
    return when (item.itemId) {
        R.id.action_app_home -> { goAppHome(); true }
        R.id.action_profile_home -> { load(startUrl, forceNoCache = false); true }
        R.id.action_profiles -> { showProfiles(); true }
        R.id.action_add_bookmark -> { addBookmark(); true }
        R.id.action_bookmarks -> { showBookmarks(); true }
        R.id.action_reload -> { reloadCurrent(); true }
        R.id.action_clear_profile -> { clearThisProfile(); true }
        R.id.action_rename_profile -> { renameProfile(); true }
        R.id.action_toggle_theme -> { ThemeStore.toggle(this); recreate(); true }
        R.id.action_open_external -> { openExternal(web.url ?: startUrl); true }
        R.id.action_profile_settings -> { showProfileSettingsDialog(); true }
        R.id.action_clear_site_cookies -> { clearCookiesForCurrentSite(); true }
        else -> super.onOptionsItemSelected(item)
    }
}

private fun goAppHome() {
    val intent = Intent(this, MainActivity::class.java).apply {
        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    }
    startActivity(intent)
}

private fun reloadCurrent() {
    val u = web.url
    if (!u.isNullOrBlank()) {
        // Proper reload of the current page
        web.reload()
    } else {
        load(startUrl, forceNoCache = true)
    }
}

private fun openExternal(url: String) {
    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
}

private fun showProfiles() {
    val max = ProfileStore.getMaxProfiles(this)
    val names = (1..max).map { i -> ProfileStore.getName(this, i) }.toMutableList()
    names.add("➕ Add profile")

    MaterialAlertDialogBuilder(this)
        .setTitle("Switch profile")
        .setItems(names.toTypedArray()) { _, which ->
            if (which == max) {
                val newMax = ProfileStore.addOneProfile(this)
                Toast.makeText(this, "Added profile $newMax", Toast.LENGTH_SHORT).show()
                showProfiles()
                return@setItems
            }

            val target = which + 1
            if (target == profileId) return@setItems
            try {
                val cls = Class.forName("com.example.minigologin.ProfileActivity$target")
                // When switching, open the MAIN page of that profile (not the current page)
                val intent = Intent(this, cls).apply {
                    putExtra("url", startUrl)
                    putExtra("profile", target)
                }
                startActivity(intent)
            } catch (_: Exception) {}
        }
        .setNegativeButton("Cancel", null)
        .show()
}

private fun addBookmark() {
    val url = web.url ?: startUrl
    val defaultTitle = (web.title ?: url).take(80)

    val til = TextInputLayout(this).apply {
        hint = "Bookmark name"
        setPadding(24, 8, 24, 0)
    }
    val input = TextInputEditText(this).apply {
        setText(defaultTitle)
    }
    til.addView(input)

    MaterialAlertDialogBuilder(this)
        .setTitle("Add bookmark")
        .setView(til)
        .setPositiveButton("Save") { _, _ ->
            val title = input.text?.toString()?.trim().orEmpty().ifBlank { defaultTitle }
            // Global bookmarks for all profiles
            BookmarkStore.add(this, title, url)
        }
        .setNegativeButton("Cancel", null)
        .show()
}

private fun showBookmarks() {
    val list = BookmarkStore.list(this)
    if (list.isEmpty()) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Bookmarks")
            .setMessage("No bookmarks saved yet.")
            .setPositiveButton("OK", null)
            .show()
        return
    }

    val titles = list.map { it.title }.toTypedArray()
    MaterialAlertDialogBuilder(this)
        .setTitle("Bookmarks")
        .setItems(titles) { _, which ->
            val b = list[which]
            MaterialAlertDialogBuilder(this)
                .setTitle(b.title)
                .setMessage(b.url)
                .setPositiveButton("Open") { _, _ -> load(b.url, forceNoCache = false) }
                .setNeutralButton("Delete") { _, _ -> BookmarkStore.deleteAt(this, which) }
                .setNegativeButton("Cancel", null)
                .show()
        }
        .setNegativeButton("Close", null)
        .show()
}

private fun clearThisProfile() {
    MaterialAlertDialogBuilder(this)
        .setTitle("Clear profile data")
        .setMessage("This will log out and clear cookies/cache for ${ProfileStore.getName(this, profileId)} only.")
        .setPositiveButton("Clear") { _, _ ->
            try {
                // These operate within this profile process (isolated by data directory suffix)
                web.clearHistory()
                web.clearCache(true)
                android.webkit.WebStorage.getInstance().deleteAllData()
                val cm = android.webkit.CookieManager.getInstance()
                cm.removeAllCookies(null)
                cm.removeSessionCookies(null)
                cm.flush()
            } catch (_: Exception) {}
            load(startUrl, forceNoCache = true)
        }
        .setNegativeButton("Cancel", null)
        .show()
}

override fun onBackPressed() {
        if (this::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }


private fun renameProfile() {
    val input = com.google.android.material.textfield.TextInputEditText(this).apply {
        setText(ProfileStore.getName(this@BaseProfileActivity, profileId))
        hint = "Profile name"
    }
    val box = com.google.android.material.textfield.TextInputLayout(this).apply {
        setPadding(32, 16, 32, 0)
        addView(input)
    }
    MaterialAlertDialogBuilder(this)
        .setTitle("Rename profile")
        .setView(box)
        .setPositiveButton("Save") { _, _ ->
            val name = input.text?.toString()?.trim().orEmpty()
            ProfileStore.setName(this, profileId, if (name.isBlank()) "Profile $profileId" else name)
            Toast.makeText(this, "Renamed", Toast.LENGTH_SHORT).show()
        }
        .setNegativeButton("Cancel", null)
        .show()
}

private fun applyProfileNetworkSettings() {
    // User-Agent
    val mode = ProfileStore.getUaMode(this, profileId)
    val ua = when (mode) {
        "mobile" -> DEFAULT_MOBILE_UA
        "desktop" -> DEFAULT_DESKTOP_UA
        "custom" -> ProfileStore.getUaCustom(this, profileId).ifBlank { web.settings.userAgentString }
        else -> web.settings.userAgentString // system/default
    }
    web.settings.userAgentString = ua
}

private fun headersForLoad(): MutableMap<String, String> {
    val lang = ProfileStore.getAcceptLanguage(this, profileId).trim()
    val h = mutableMapOf<String, String>()
    if (lang.isNotEmpty()) h["Accept-Language"] = lang
    return h
}

private fun loadWithHeaders(url: String) {
    val headers = headersForLoad()
    if (headers.isEmpty()) {
        web.loadUrl(url)
    } else {
        web.loadUrl(url, headers)
    }
}

private fun showProfileSettingsDialog() {
    val v = layoutInflater.inflate(R.layout.dialog_profile_settings, null)
    val spinner = v.findViewById<Spinner>(R.id.uaModeSpinner)
    val customUa = v.findViewById<EditText>(R.id.customUaInput)
    val lang = v.findViewById<EditText>(R.id.langInput)

    val modes = listOf(
        "System (default)" to "system",
        "Mobile UA" to "mobile",
        "Desktop UA" to "desktop",
        "Custom UA" to "custom"
    )
    val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, modes.map { it.first })
    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    spinner.adapter = adapter

    val currentMode = ProfileStore.getUaMode(this, profileId)
    val idx = modes.indexOfFirst { it.second == currentMode }.let { if (it < 0) 0 else it }
    spinner.setSelection(idx)

    customUa.setText(ProfileStore.getUaCustom(this, profileId))
    lang.setText(ProfileStore.getAcceptLanguage(this, profileId))

    AlertDialog.Builder(this)
        .setTitle("Profile settings")
        .setView(v)
        .setPositiveButton("Save") { _, _ ->
            val selected = modes[spinner.selectedItemPosition].second
            ProfileStore.setUaMode(this, profileId, selected)
            ProfileStore.setUaCustom(this, profileId, customUa.text?.toString() ?: "")
            ProfileStore.setAcceptLanguage(this, profileId, lang.text?.toString() ?: "")
            applyProfileNetworkSettings()
            Toast.makeText(this, "Saved. Reload page for full effect.", Toast.LENGTH_SHORT).show()
        }
        .setNegativeButton("Cancel", null)
        .show()
}

private fun clearCookiesForCurrentSite() {
    val url = web.url ?: return
    val host = try { URI(url).host ?: "" } catch (_: Exception) { "" }
    if (host.isBlank()) return

    val cm = CookieManager.getInstance()
    val cookieStr = cm.getCookie(url) ?: ""
    if (cookieStr.isBlank()) {
        Toast.makeText(this, "No cookies found for this site.", Toast.LENGTH_SHORT).show()
        return
    }

    // Expire each cookie for the current host (best-effort).
    val parts = cookieStr.split(";")
    for (p in parts) {
        val name = p.trim().substringBefore("=")
        if (name.isNotBlank()) {
            cm.setCookie(url, "$name=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/")
        }
    }
    cm.flush()
    Toast.makeText(this, "Cleared cookies for $host", Toast.LENGTH_SHORT).show()
    web.reload()
}

companion object {
    // Common, reasonably modern UA defaults (not guaranteed to be identical to Chrome)
    private const val DEFAULT_DESKTOP_UA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    private const val DEFAULT_MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36"
}
