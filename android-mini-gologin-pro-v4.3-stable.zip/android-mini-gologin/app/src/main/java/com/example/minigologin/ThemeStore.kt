package com.example.minigologin

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

object ThemeStore {
    private const val PREF = "mini_gologin"
    private const val KEY = "theme_mode" // 0=FOLLOW_SYSTEM, 1=LIGHT, 2=DARK

    fun applySaved(context: Context) {
        when (getMode(context)) {
            1 -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            2 -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    fun toggle(context: Context) {
        val now = getMode(context)
        val next = when (now) {
            2 -> 1
            1 -> 0
            else -> 2
        }
        setMode(context, next)
        applySaved(context)
    }

    private fun getMode(context: Context): Int {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt(KEY, 0)
    }

    private fun setMode(context: Context, mode: Int) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt(KEY, mode).apply()
    }
}
