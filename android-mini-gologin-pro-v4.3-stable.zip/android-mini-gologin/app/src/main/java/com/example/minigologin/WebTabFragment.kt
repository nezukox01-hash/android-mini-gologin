
package com.example.minigologin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment

class WebTabFragment : Fragment() {

    private lateinit var webView: WebView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        webView = WebView(requireContext())
        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()

        val url = arguments?.getString("url") ?: "https://www.google.com"
        webView.loadUrl(url)

        return webView
    }

    companion object {
        fun newInstance(url: String): WebTabFragment {
            val fragment = WebTabFragment()
            val args = Bundle()
            args.putString("url", url)
            fragment.arguments = args
            return fragment
        }
    }
}
