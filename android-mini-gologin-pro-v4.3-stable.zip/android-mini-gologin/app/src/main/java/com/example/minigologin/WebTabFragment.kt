package com.example.minigologin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment

class WebTabFragment : Fragment() {

    private var webView: WebView? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val wv = WebView(requireContext())
        wv.settings.javaScriptEnabled = true
        wv.webViewClient = WebViewClient()

        val url = arguments?.getString("url") ?: "https://www.google.com"
        wv.loadUrl(url)

        webView = wv
        return wv
    }

    override fun onDestroyView() {
        super.onDestroyView()
        webView = null
    }

    fun getWebViewOrNull(): WebView? = webView

    companion object {
        fun newInstance(url: String): WebTabFragment {
            val fragment = WebTabFragment()
            val args = Bundle()
            args.putString("url", url)
            fragment.arguments = args
            return fragment
        }
    }
}
