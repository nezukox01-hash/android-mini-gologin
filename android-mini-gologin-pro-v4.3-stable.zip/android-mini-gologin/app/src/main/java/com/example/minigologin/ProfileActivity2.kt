package com.example.minigologin

class ProfileActivity2 : BaseProfileActivity()
