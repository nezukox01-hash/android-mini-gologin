package com.example.minigologin

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object SettingsBackup {
    private const val PREF = "mini_gologin"

    fun exportJson(context: Context): String {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val root = JSONObject()

        // copy all primitive prefs we use
        root.put("theme_mode", sp.getInt("theme_mode", 0))
        root.put("max_profiles", sp.getInt("max_profiles", 20))

        // profile names
        val names = JSONArray()
        val max = root.getInt("max_profiles")
        for (i in 1..max) {
            val key = "profile_name_$i"
            if (sp.contains(key)) {
                val o = JSONObject()
                o.put("id", i)
                o.put("name", sp.getString(key, "Profile $i"))
                names.put(o)
            }
        }
        root.put("profile_names", names)

        // bookmarks (global)
        root.put("bookmarks_global", sp.getString("bookmarks_global", "[]") ?: "[]")

        return root.toString(2)
    }

    fun importJson(context: Context, json: String) {
        val root = JSONObject(json)
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val ed = sp.edit()

        ed.putInt("theme_mode", root.optInt("theme_mode", 0))
        ed.putInt("max_profiles", root.optInt("max_profiles", 20))
        ed.putString("bookmarks_global", root.optString("bookmarks_global", "[]"))

        val names = root.optJSONArray("profile_names") ?: JSONArray()
        for (i in 0 until names.length()) {
            val o = names.optJSONObject(i) ?: continue
            val id = o.optInt("id", -1)
            val name = o.optString("name", "")
            if (id > 0 && name.isNotBlank()) {
                ed.putString("profile_name_$id", name)
            }
        }
        ed.apply()
    }
}
