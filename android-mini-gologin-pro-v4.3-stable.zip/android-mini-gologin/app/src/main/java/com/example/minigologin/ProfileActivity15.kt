package com.example.minigologin

class ProfileActivity15 : BaseProfileActivity()
