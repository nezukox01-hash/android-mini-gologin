package com.example.minigologin

class ProfileActivity17 : BaseProfileActivity()
