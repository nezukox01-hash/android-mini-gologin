package com.example.minigologin

class ProfileActivity10 : BaseProfileActivity()
