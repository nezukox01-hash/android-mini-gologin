package com.example.minigologin

class ProfileActivity5 : BaseProfileActivity()
