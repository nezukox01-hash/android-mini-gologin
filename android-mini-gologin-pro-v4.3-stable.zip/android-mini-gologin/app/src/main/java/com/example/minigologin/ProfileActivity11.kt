package com.example.minigologin

class ProfileActivity11 : BaseProfileActivity()
