Mini GoLogin Pro (Learning) - Android

New in v3:
- 3-dot menu inside each profile (Profiles / Add bookmark / Bookmarks / Reload / Open in browser)
- Profile switcher dialog (1–20)
- Per-profile bookmarks stored locally (SharedPreferences JSON)

Build:
- Works with GitHub Actions unzip + Gradle build
