package com.example.minigologin

import android.app.Application
import android.os.Build
import android.webkit.WebView

class MiniGoLoginApp : Application() {

    override fun onCreate() {
        // WebView storage isolation is per-PROCESS.
        // Each ProfileActivity runs in its own process (:p1..:p20) and gets its own suffix.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val processName = Application.getProcessName()
            val suffix = processName.substringAfterLast(":").takeIf { it.startsWith("p") }
            if (suffix != null) {
                WebView.setDataDirectorySuffix(suffix)
            }
        }
        super.onCreate()
    }
}
