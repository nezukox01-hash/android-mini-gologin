package com.example.minigologin

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeStore.applySaved(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val urlInput = findViewById<TextInputEditText>(R.id.urlInput)
        val profileInput = findViewById<TextInputEditText>(R.id.profileInput)
        val pickBtn = findViewById<MaterialButton>(R.id.pickProfileBtn)
        val openBtn = findViewById<MaterialButton>(R.id.openBtn)

        if (urlInput.text.isNullOrBlank()) {
            urlInput.setText("https://m.facebook.com")
        }

        
pickBtn.setOnClickListener { v ->
    val items = (1..20).map { i -> ProfileStore.getName(this, i) }.toTypedArray()
    com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
        .setTitle("Select profile")
        .setItems(items) { _, which ->
            val target = which + 1
            profileInput.setText(target.toString())
        }
        .setNegativeButton("Cancel", null)
        .show()
}

        openBtn.setOnClickListener { v ->
            val url = (urlInput.text?.toString()?.trim()).orEmpty().ifBlank { "https://m.facebook.com" }
            val n = profileInput.text?.toString()?.trim()?.toIntOrNull()

            if (n == null || n !in 1..20) {
                Snackbar.make(v, "Profile number must be 1–20", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cls = Class.forName("com.example.minigologin.ProfileActivity$n")
            val intent = Intent(this, cls).apply {
                putExtra("url", url)
                putExtra("profile", n)
            }
            startActivity(intent)
        }
    }
}
