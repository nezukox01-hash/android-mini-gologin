package com.example.minigologin

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar

abstract class BaseProfileActivity : AppCompatActivity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val profile = intent.getIntExtra("profile", -1)
        val url = intent.getStringExtra("url") ?: "https://m.facebook.com"

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.title = "Profile $profile"
        toolbar.setNavigationOnClickListener { finish() }

        val web = findViewById<WebView>(R.id.web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.loadWithOverviewMode = true
        web.settings.useWideViewPort = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()

        web.loadUrl(url)
    }

    override fun onBackPressed() {
        val web = findViewById<WebView>(R.id.web)
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
