package com.example.minigologin

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Bookmark(val title: String, val url: String, val ts: Long)

object BookmarkStore {
    private const val PREF = "mini_gologin"
    private fun key(profile: Int) = "bookmarks_p$profile"

    fun list(context: Context, profile: Int): List<Bookmark> {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val raw = sp.getString(key(profile), "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = ArrayList<Bookmark>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(
                Bookmark(
                    title = o.optString("title", "Bookmark"),
                    url = o.optString("url", ""),
                    ts = o.optLong("ts", 0L)
                )
            )
        }
        return out
    }

    fun add(context: Context, profile: Int, title: String, url: String) {
        val list = list(context, profile).toMutableList()
        // Deduplicate by url
        val existingIdx = list.indexOfFirst { it.url == url }
        if (existingIdx >= 0) list.removeAt(existingIdx)
        list.add(0, Bookmark(title.take(80), url, System.currentTimeMillis()))
        save(context, profile, list)
    }

    fun deleteAt(context: Context, profile: Int, index: Int) {
        val list = list(context, profile).toMutableList()
        if (index in list.indices) {
            list.removeAt(index)
            save(context, profile, list)
        }
    }

    private fun save(context: Context, profile: Int, list: List<Bookmark>) {
        val arr = JSONArray()
        for (b in list.take(200)) {
            val o = JSONObject()
            o.put("title", b.title)
            o.put("url", b.url)
            o.put("ts", b.ts)
            arr.put(o)
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(key(profile), arr.toString())
            .apply()
    }
}
