package com.example.minigologin

class ProfileActivity14 : BaseProfileActivity()
