package com.example.minigologin

import android.content.Context

object ProfileStore {
    private const val PREF = "mini_gologin"
    private fun key(profile: Int) = "profile_name_$profile"

    fun getName(context: Context, profile: Int): String {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return sp.getString(key(profile), null) ?: "Profile $profile"
    }

    fun ensureExists(context: Context, profile: Int) {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!sp.contains(key(profile))) {
            sp.edit().putString(key(profile), "Profile $profile").apply()
        }
    }

    fun setName(context: Context, profile: Int, name: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(key(profile), name.take(40).ifBlank { "Profile $profile" })
            .apply()
    }
}
