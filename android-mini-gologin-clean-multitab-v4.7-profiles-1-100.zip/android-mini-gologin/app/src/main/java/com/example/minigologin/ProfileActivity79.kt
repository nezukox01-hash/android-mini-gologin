package com.example.minigologin

class ProfileActivity79 : BaseProfileActivity()
