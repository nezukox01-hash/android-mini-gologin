package com.example.minigologin

class ProfileActivity74 : BaseProfileActivity()
