package com.example.minigologin

class ProfileActivity22 : BaseProfileActivity()
