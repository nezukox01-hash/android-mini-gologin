package com.example.minigologin

class ProfileActivity36 : BaseProfileActivity()
