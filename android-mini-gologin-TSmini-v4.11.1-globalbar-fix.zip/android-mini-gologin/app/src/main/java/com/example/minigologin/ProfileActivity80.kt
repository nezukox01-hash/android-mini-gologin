package com.example.minigologin

class ProfileActivity80 : BaseProfileActivity()
