package com.example.minigologin

class ProfileActivity26 : BaseProfileActivity()
