package com.example.minigologin

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Menu
import android.view.MenuItem
import android.view.inputmethod.EditorInfo
import android.text.InputType
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatEditText
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

open class BaseProfileActivity : AppCompatActivity() {

    private lateinit var toolbar: MaterialToolbar
    private lateinit var tabLayout: TabLayout
    private lateinit var viewPager: ViewPager2
    private lateinit var urlBox: AppCompatEditText
    private lateinit var profileBtn: ImageButton

    private var currentUserAgent: String = ""
    private var currentAcceptLanguage: String = ""

    private lateinit var adapter: TabsAdapter
    private val tabs = mutableListOf<WebTabFragment>()

    private val profileId: Int by lazy {
        // IMPORTANT:
        // Always prefer an explicit profile id passed via Intent extras.
        // This prevents "Profile 2" from behaving like a different profile when opened from different entry points.
        intent.getIntExtra("profile_id",
            intent.getIntExtra("profile",
                Regex("ProfileActivity(\\d+)")
                    .find(this::class.java.simpleName)
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.toIntOrNull()
                    ?: 1
            )
        ).coerceIn(1, 100)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        tabLayout = findViewById(R.id.tabLayout)
        viewPager = findViewById(R.id.viewPager)
        urlBox = findViewById(R.id.urlBox)
        profileBtn = findViewById(R.id.profileBtn)

        // Title uses saved profile name if present
        val title = ProfileStore.getProfileName(this, profileId) ?: "Profile $profileId"
        supportActionBar?.title = title

        // Per-profile settings (UA / Accept-Language)
        currentUserAgent = ProfileSettingsStore.getUserAgent(this, profileId)
        currentAcceptLanguage = ProfileSettingsStore.getAcceptLanguage(this, profileId)

        val startUrl = intent.getStringExtra("url") ?: intent.getStringExtra("start_url") ?: "https://www.google.com"
        tabs.add(WebTabFragment.newInstance(normalizeUrl(startUrl), currentUserAgent, currentAcceptLanguage))

        adapter = TabsAdapter(this, tabs)
        viewPager.adapter = adapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = "Tab ${position + 1}"
        }.attach()

        // Sync URL bar when switching tabs
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                urlBox.setText(currentWebView()?.url ?: "")
            }
        })

        // Navigate from URL bar
        urlBox.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                val u = normalizeUrl(urlBox.text?.toString() ?: "")
                if (u.isNotBlank()) {
                    loadUrl(u)
                }
                true
            } else false
        }

        // Quick profile switch (small round button)
        profileBtn.setOnClickListener { showProfilePicker() }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.profile_tabs_menu, menu)
        menuInflater.inflate(R.menu.profile_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_new_tab -> { addNewTab(); true }
            R.id.action_close_tab -> { closeCurrentTab(); true }
            R.id.action_refresh -> { currentWebView()?.reload(); true }
            R.id.action_home -> { loadUrl("https://m.facebook.com"); true }

            R.id.action_app_home -> {
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                finish()
                true
            }
            R.id.action_profile_home -> { loadUrl("https://m.facebook.com"); true }
            R.id.action_profiles -> { showProfilePicker(); true }
            R.id.action_profile_settings -> { showProfileSettings(); true }
            R.id.action_add_bookmark -> { addBookmarkForCurrentTab(); true }
            R.id.action_bookmarks -> { showBookmarks(); true }
            R.id.action_reload -> { currentWebView()?.reload(); true }
            R.id.action_clear_profile_data -> { clearThisProfileData(); true }
            R.id.action_rename_profile -> { renameProfile(); true }
            R.id.action_open_external -> { openInBrowser(); true }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun currentWebView(): WebView? {
        val idx = viewPager.currentItem.coerceIn(0, tabs.size - 1)
        return tabs.getOrNull(idx)?.getWebViewOrNull()
    }

    
private fun buildHeaders(): Map<String, String> {
    val lang = currentAcceptLanguage.trim()
    return if (lang.isBlank()) emptyMap() else mapOf("Accept-Language" to lang)
}

fun addNewTab(url: String = "https://www.google.com") {
        tabs.add(WebTabFragment.newInstance(normalizeUrl(url), currentUserAgent, currentAcceptLanguage))
        adapter.notifyItemInserted(tabs.size - 1)
        viewPager.setCurrentItem(tabs.size - 1, true)
        Snackbar.make(findViewById(android.R.id.content), "New tab opened", Snackbar.LENGTH_SHORT).show()
    }

    private fun closeCurrentTab() {
        val idx = tabLayout.selectedTabPosition.takeIf { it >= 0 } ?: viewPager.currentItem
        if (tabs.size <= 1) {
            Toast.makeText(this, "Can't close the last tab", Toast.LENGTH_SHORT).show()
            return
        }
        if (idx < 0 || idx >= tabs.size) return

        tabs.removeAt(idx)
        adapter.notifyItemRemoved(idx)

        val newIdx = (idx - 1).coerceAtLeast(0).coerceAtMost(tabs.size - 1)
        viewPager.setCurrentItem(newIdx, false)
        updateUrlBox()
    }

    private fun updateUrlBox() {
        urlBox.setText(currentWebView()?.url ?: "")
    }

    private fun loadUrl(input: String) {
    val t = input.trim()
    if (t.startsWith("javascript:", ignoreCase = true)) {
        executeBookmark(t)
        return
    }
    val url = normalizeUrl(t)
    val hdrs = buildHeaders()
    if (hdrs.isEmpty()) currentWebView()?.loadUrl(url) else currentWebView()?.loadUrl(url, hdrs)
    urlBox.setText(url)
}


private fun executeBookmark(raw: String) {
    val trimmed = raw.trim()
    if (trimmed.isEmpty()) return
    val wv = currentWebView() ?: return

    // Run bookmarklets directly in the current tab
    if (trimmed.startsWith("javascript:", ignoreCase = true)) {
        val js = trimmed.removePrefix("javascript:")
        wv.evaluateJavascript(js, null)
        Toast.makeText(this, "Script executed", Toast.LENGTH_SHORT).show()
        return
    }

    // Normal URL
    val url = normalizeUrl(trimmed)
    wv.loadUrl(url)
    urlBox.setText(url)
}

    private fun normalizeUrl(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return "https://m.facebook.com"
        return when {
            trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true) -> trimmed
            else -> "https://$trimmed"
        }
    }

    
private fun showProfileSettings() {
    val container = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val pad = (16 * resources.displayMetrics.density).toInt()
        setPadding(pad, pad, pad, pad)
    }

    val uaBox = AppCompatEditText(this).apply {
        hint = "User-Agent (leave empty = default)"
        setText(currentUserAgent)
        inputType = InputType.TYPE_CLASS_TEXT
    }
    val langBox = AppCompatEditText(this).apply {
        hint = "Accept-Language (e.g., en-US,en;q=0.9 or bn-BD,bn;q=0.9)"
        setText(currentAcceptLanguage)
        inputType = InputType.TYPE_CLASS_TEXT
    }

    container.addView(uaBox)
    container.addView(langBox)

    AlertDialog.Builder(this)
        .setTitle("Profile settings (Profile $profileId)")
        .setView(container)
        .setNeutralButton("Reset") { _, _ ->
            ProfileSettingsStore.clear(this, profileId)
            currentUserAgent = ""
            currentAcceptLanguage = ""
            Toast.makeText(this, "Reset settings. Reopen tabs to apply.", Toast.LENGTH_SHORT).show()
        }
        .setNegativeButton("Cancel", null)
        .setPositiveButton("Save") { _, _ ->
            currentUserAgent = uaBox.text?.toString().orEmpty().trim()
            currentAcceptLanguage = langBox.text?.toString().orEmpty().trim()
            ProfileSettingsStore.setUserAgent(this, profileId, currentUserAgent)
            ProfileSettingsStore.setAcceptLanguage(this, profileId, currentAcceptLanguage)
            Toast.makeText(this, "Saved. New tabs will use updated settings.", Toast.LENGTH_SHORT).show()
        }
        .show()
}

private fun showProfilePicker() {
    val currentMax = ProfileStore.getMaxProfiles(this).coerceAtMost(100)
    val labels = (1..currentMax).map { i ->
        ProfileStore.getProfileName(this, i) ?: "Profile $i"
    }.toMutableList()

    // Allow creating more profiles from anywhere
    if (currentMax < 100) {
        labels.add("➕ Add profile")
    }

    AlertDialog.Builder(this)
        .setTitle("Switch profile")
        .setItems(labels.toTypedArray()) { _, which ->
            // Last item = Add profile
            if (currentMax < 100 && which == labels.lastIndex) {
                val next = (currentMax + 1).coerceAtMost(100)
                ProfileStore.setMaxProfiles(this, next)
                Toast.makeText(this, "Created Profile $next", Toast.LENGTH_SHORT).show()
                // Immediately switch to the new profile
                val cls = Class.forName("${packageName}.ProfileActivity$next")
                startActivity(Intent(this, cls).putExtra("profile_id", next))
                finish()
                return@setItems
            }

            val targetId = which + 1
            if (targetId == profileId) return@setItems
            val cls = Class.forName("${packageName}.ProfileActivity$targetId")
            startActivity(Intent(this, cls).putExtra("profile_id", targetId))
            finish()
        }
        .setNegativeButton("Cancel", null)
        .show()
}


    private fun addBookmarkForCurrentTab() {
        val wv = currentWebView()
        val url = wv?.url
        if (url.isNullOrBlank()) {
            Toast.makeText(this, "No page to bookmark", Toast.LENGTH_SHORT).show()
            return
        }
        val title = (wv?.title?.takeIf { it.isNotBlank() } ?: url)
        BookmarkStore.add(applicationContext, title, url)
        Toast.makeText(this, "Bookmark added", Toast.LENGTH_SHORT).show()
    }

    private fun showBookmarks() {
        val list = BookmarkStore.getAll(applicationContext)
        if (list.isEmpty()) {
            Toast.makeText(this, "No bookmarks yet", Toast.LENGTH_SHORT).show()
            return
        }

        val labels = list.map { it.title }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Bookmarks")
            .setItems(labels) { _, which ->
                val b = list[which]
                AlertDialog.Builder(this)
                    .setTitle(b.title)
                    .setItems(arrayOf("Open", "Edit", "Delete")) { _, action ->
                        when (action) {
                            0 -> loadUrl(b.url)
                            1 -> showEditBookmarkDialog(which, b.title, b.url)
                            2 -> {
                                BookmarkStore.deleteAt(applicationContext, which)
                                Toast.makeText(this, "Bookmark deleted", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showEditBookmarkDialog(index: Int, oldTitle: String, oldUrl: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }

        val titleInput = AppCompatEditText(this).apply {
            hint = "Name"
            setText(oldTitle)
        }
        val urlInput = AppCompatEditText(this).apply {
            hint = "URL"
            setText(oldUrl)
        }

        box.addView(titleInput)
        box.addView(urlInput)

        AlertDialog.Builder(this)
            .setTitle("Edit bookmark")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val nt = titleInput.text?.toString() ?: ""
                val nu = urlInput.text?.toString() ?: ""
                if (nu.isBlank()) {
                    Toast.makeText(this, "URL can't be empty", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                BookmarkStore.updateAt(applicationContext, index, nt, nu)
                Toast.makeText(this, "Bookmark updated", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun clearThisProfileData() {
        // Best-effort clearing for the current WebView process/profile
        currentWebView()?.apply {
            clearHistory()
            clearCache(true)
            clearFormData()
        }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()

        Toast.makeText(this, "Cleared this profile data", Toast.LENGTH_SHORT).show()
        loadUrl("https://m.facebook.com")
    }

    private fun renameProfile() {
        val input = AppCompatEditText(this).apply {
            setText(ProfileStore.getProfileName(this@BaseProfileActivity, profileId) ?: "")
            hint = "Profile name"
        }
        AlertDialog.Builder(this)
            .setTitle("Rename profile")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text?.toString()?.trim().orEmpty()
                if (name.isBlank()) {
                    ProfileStore.clearProfileName(this, profileId)
                    supportActionBar?.title = "Profile $profileId"
                } else {
                    ProfileStore.setProfileName(this, profileId, name)
                    supportActionBar?.title = name
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openInBrowser() {
        val url = currentWebView()?.url ?: return
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }.onFailure {
            Toast.makeText(this, "Can't open browser", Toast.LENGTH_SHORT).show()
        }
    }


    // normalizeUrl() is defined earlier in this file.
}
