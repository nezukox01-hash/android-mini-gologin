package com.example.minigologin

class ProfileActivity78 : BaseProfileActivity()
