package com.example.minigologin

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private val createBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            try {
                val stats = BackupManager.exportAll(this, uri)
                Toast.makeText(this, "Backup saved (${stats.files} files)", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Backup failed: ${'$'}{e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val pickRestoreLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val stats = BackupManager.importAll(this, uri)
                Toast.makeText(this, "Restore done (${stats.files} files). Please restart app.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Restore failed: ${'$'}{e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeStore.applySaved(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val urlInput = findViewById<TextInputEditText>(R.id.urlInput)
        val profileInput = findViewById<TextInputEditText>(R.id.profileInput)
        val pickBtn = findViewById<MaterialButton>(R.id.pickProfileBtn)
        val openBtn = findViewById<MaterialButton>(R.id.openBtn)
        val backupBtn = findViewById<MaterialButton>(R.id.backupBtn)
        val restoreBtn = findViewById<MaterialButton>(R.id.restoreBtn)

        if (urlInput.text.isNullOrBlank()) {
            urlInput.setText("https://m.facebook.com")
        }

        
pickBtn.setOnClickListener { _ ->
            showProfilePicker { picked ->
                profileInput.setText(picked.toString())
            }
        }

        openBtn.setOnClickListener { v ->
            val url = normalizeUrl(urlInput.text?.toString() ?: "")
            val n = profileInput.text?.toString()?.trim()?.toIntOrNull()
            val max = ProfileStore.getMaxProfiles(this)

            if (n == null || n !in 1..max) {
                Snackbar.make(v, "Profile number must be 1–$max", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cls = Class.forName("com.example.minigologin.ProfileActivity$n")
            val intent = Intent(this, cls).apply {
                putExtra("url", url)
                putExtra("profile_id", n)
            }
            startActivity(intent)
        }

        backupBtn.setOnClickListener {
            // Save to user-chosen location (Downloads etc.)
            createBackupLauncher.launch("TSmini-backup.zip")
        }

        restoreBtn.setOnClickListener {
            // Pick a backup zip and restore into app storage
            pickRestoreLauncher.launch(arrayOf("application/zip"))
        }

    }


    private fun normalizeUrl(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return "https://m.facebook.com"
        val lower = s.lowercase()
        return if (lower.startsWith("http://") || lower.startsWith("https://")) s
        else "https://$s"
    }

    private fun showProfilePicker(onPick: (Int) -> Unit) {
        val max = ProfileStore.getMaxProfiles(this)
        val names = (1..max).map { i -> ProfileStore.getName(this, i) }.toMutableList()
        names.add("➕ Add profile")
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Select profile")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == max) {
                    val newMax = ProfileStore.addOneProfile(this)
                    Snackbar.make(findViewById(android.R.id.content), "Added profile $newMax", Snackbar.LENGTH_SHORT).show()
                    showProfilePicker(onPick)
                } else {
                    onPick(which + 1)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
