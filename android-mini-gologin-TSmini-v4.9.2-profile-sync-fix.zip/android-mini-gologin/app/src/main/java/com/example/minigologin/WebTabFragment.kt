package com.example.minigologin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class WebTabFragment : Fragment() {

    private var webView: WebView? = null

    private fun headers(): Map<String, String> {
        val lang = arguments?.getString("accept_lang")?.trim().orEmpty()
        return if (lang.isBlank()) emptyMap() else mapOf("Accept-Language" to lang)
    }

    private fun applyUserAgent(wv: WebView) {
        val ua = arguments?.getString("user_agent")?.trim().orEmpty()
        if (ua.isNotBlank()) {
            wv.settings.userAgentString = ua
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val ctx = requireContext()

        val swipeLayout = SwipeRefreshLayout(ctx)
        val wv = WebView(ctx)

        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true

        applyUserAgent(wv)

        // Needed for alert(), confirm(), prompt()
        wv.webChromeClient = WebChromeClient()

        val hdrs = headers()

        wv.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (!request.isForMainFrame) return false
                // Let javascript: urls run normally
                if (url.startsWith("javascript:", ignoreCase = true)) return false
                view?.loadUrl(url, hdrs)
                return true
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                val u = url ?: return false
                if (u.startsWith("javascript:", ignoreCase = true)) return false
                view?.loadUrl(u, hdrs)
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                swipeLayout.isRefreshing = false
            }
        }

        swipeLayout.setOnRefreshListener { wv.reload() }
        swipeLayout.setOnChildScrollUpCallback { _, _ -> wv.scrollY > 0 }

        swipeLayout.addView(
            wv,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val url = arguments?.getString("url") ?: "https://www.google.com"
        if (hdrs.isEmpty()) {
            wv.loadUrl(url)
        } else {
            wv.loadUrl(url, hdrs)
        }

        webView = wv
        return swipeLayout
    }

    override fun onDestroyView() {
        super.onDestroyView()
        webView = null
    }

    fun getWebViewOrNull(): WebView? = webView

    companion object {
        fun newInstance(url: String, userAgent: String = "", acceptLanguage: String = ""): WebTabFragment {
            val fragment = WebTabFragment()
            val args = Bundle()
            args.putString("url", url)
            args.putString("user_agent", userAgent)
            args.putString("accept_lang", acceptLanguage)
            fragment.arguments = args
            return fragment
        }
    }
}
