package com.example.minigologin

class ProfileActivity20 : BaseProfileActivity()
