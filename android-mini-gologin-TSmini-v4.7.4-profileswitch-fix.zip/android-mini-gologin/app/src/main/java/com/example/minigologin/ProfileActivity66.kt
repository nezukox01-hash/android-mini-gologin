package com.example.minigologin

class ProfileActivity66 : BaseProfileActivity()
