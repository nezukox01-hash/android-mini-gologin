package com.example.minigologin

class ProfileActivity19 : BaseProfileActivity()
