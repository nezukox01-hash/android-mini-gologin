package com.example.minigologin

class ProfileActivity23 : BaseProfileActivity()
