package com.example.minigologin

class ProfileActivity25 : BaseProfileActivity()
