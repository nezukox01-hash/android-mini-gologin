package com.example.minigologin

class ProfileActivity96 : BaseProfileActivity()
