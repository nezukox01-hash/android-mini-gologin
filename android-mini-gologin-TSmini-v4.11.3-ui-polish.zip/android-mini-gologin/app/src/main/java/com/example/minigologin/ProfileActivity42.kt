package com.example.minigologin

class ProfileActivity42 : BaseProfileActivity()
