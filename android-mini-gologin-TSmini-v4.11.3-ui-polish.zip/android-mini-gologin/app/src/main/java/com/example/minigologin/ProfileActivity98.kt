package com.example.minigologin

class ProfileActivity98 : BaseProfileActivity()
