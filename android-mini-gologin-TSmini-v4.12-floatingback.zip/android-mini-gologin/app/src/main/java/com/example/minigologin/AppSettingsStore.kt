package com.example.minigologin

import android.content.Context
import android.content.Intent

/** App-wide settings (apply to all profiles/tabs). */
object AppSettingsStore {
    private const val PREFS = "app_settings"

    private const val KEY_TEXT_ONLY = "text_only"

    // Start page settings (global)
    private const val KEY_START_MODE = "start_mode" // google | duckduckgo | custom
    private const val KEY_START_CUSTOM = "start_custom"

    const val ACTION_TEXT_ONLY_CHANGED = "com.example.minigologin.TEXT_ONLY_CHANGED"
    const val ACTION_START_PAGE_CHANGED = "com.example.minigologin.START_PAGE_CHANGED"

    fun isTextOnlyEnabled(ctx: Context): Boolean {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_TEXT_ONLY, false)
    }

    fun setTextOnlyEnabled(ctx: Context, enabled: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_TEXT_ONLY, enabled)
            .apply()
    }

    fun broadcastTextOnlyChanged(ctx: Context) {
        ctx.sendBroadcast(Intent(ACTION_TEXT_ONLY_CHANGED))
    }

    /** Returns the current start page URL (used for new tabs / profile home). */
    fun getStartUrl(ctx: Context): String {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return when (prefs.getString(KEY_START_MODE, "google") ?: "google") {
            "duckduckgo" -> "https://duckduckgo.com"
            "custom" -> {
                val raw = (prefs.getString(KEY_START_CUSTOM, "") ?: "").trim()
                if (raw.isBlank()) "https://www.google.com" else normalizeStartUrl(raw)
            }
            else -> "https://www.google.com"
        }
    }

    fun getStartMode(ctx: Context): String {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_START_MODE, "google") ?: "google"
    }

    fun getCustomStartUrl(ctx: Context): String {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_START_CUSTOM, "") ?: ""
    }

    fun setStartMode(ctx: Context, mode: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_START_MODE, mode)
            .apply()
    }

    fun setCustomStartUrl(ctx: Context, url: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_START_CUSTOM, url)
            .apply()
    }

    fun broadcastStartPageChanged(ctx: Context) {
        ctx.sendBroadcast(Intent(ACTION_START_PAGE_CHANGED))
    }

    private fun normalizeStartUrl(input: String): String {
        val s = input.trim()
        // Accept:
        // - https://example.com
        // - http://example.com
        // - www.example.com
        // - example.com
        return when {
            s.startsWith("http://", true) || s.startsWith("https://", true) -> s
            s.startsWith("www.", true) -> "https://$s"
            else -> "https://$s"
        }
    }
}
