package com.example.minigologin

class ProfileActivity31 : BaseProfileActivity()
