package com.example.minigologin

class ProfileActivity99 : BaseProfileActivity()
