package com.example.minigologin

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup/Restore for learning/dev use.
 *
 * What it tries to include:
 * - WebView storage dirs created by setDataDirectorySuffix("pX") => app_webview_pX
 * - SharedPreferences (mini_gologin + profile_settings + any other prefs)
 *
 * Notes:
 * - Restore should be done when no profile WebView is running.
 * - After restore, app should be restarted.
 */
object BackupManager {

    data class BackupStats(val files: Int, val bytes: Long)

    private fun dataDir(ctx: Context): File = File(ctx.applicationInfo.dataDir)
    private fun sharedPrefsDir(ctx: Context): File = File(dataDir(ctx), "shared_prefs")

    private fun webViewDirForSuffix(ctx: Context, suffix: String): File = File(dataDir(ctx), "app_webview_$suffix")

    fun existingProfileWebViewDirs(ctx: Context, maxProfiles: Int): List<Pair<String, File>> {
        val out = ArrayList<Pair<String, File>>()
        for (i in 1..maxProfiles) {
            val suffix = "p$i"
            val dir = webViewDirForSuffix(ctx, suffix)
            if (dir.exists() && dir.isDirectory) out.add(suffix to dir)
        }
        return out
    }

    fun exportAll(ctx: Context, outUri: Uri): BackupStats {
        var fileCount = 0
        var byteCount = 0L

        ctx.contentResolver.openOutputStream(outUri)?.use { os ->
            ZipOutputStream(BufferedOutputStream(os)).use { zip ->
                // metadata
                val meta = "TS mini backup\ncreated=${System.currentTimeMillis()}\n"
                zip.putNextEntry(ZipEntry("META.txt"))
                zip.write(meta.toByteArray())
                zip.closeEntry()

                // shared_prefs
                val spDir = sharedPrefsDir(ctx)
                if (spDir.exists()) {
                    spDir.listFiles()?.forEach { f ->
                        if (f.isFile && f.name.endsWith(".xml")) {
                            val rel = "shared_prefs/${f.name}"
                            fileCount += addFile(zip, f, rel).also { byteCount += it }
                        }
                    }
                }

                // webview per profile
                val max = ProfileStore.getMaxProfiles(ctx)
                for ((suffix, dir) in existingProfileWebViewDirs(ctx, max)) {
                    fileCount += addDir(zip, dir, "webview/$suffix/").also { byteCount += it }
                }
            }
        } ?: throw IllegalStateException("Cannot open output stream for Uri")

        return BackupStats(fileCount, byteCount)
    }

    fun importAll(ctx: Context, inUri: Uri): BackupStats {
        var fileCount = 0
        var byteCount = 0L

        ctx.contentResolver.openInputStream(inUri)?.use { ins ->
            ZipInputStream(BufferedInputStream(ins)).use { zip ->
                var entry: ZipEntry? = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (!entry.isDirectory) {
                        val target = when {
                            name.startsWith("shared_prefs/") -> File(sharedPrefsDir(ctx), name.removePrefix("shared_prefs/"))
                            name.startsWith("webview/") -> {
                                // webview/<suffix>/...  -> dataDir/app_webview_<suffix>/...
                                val rest = name.removePrefix("webview/")
                                val parts = rest.split("/", limit = 2)
                                if (parts.size < 2) null else {
                                    val suffix = parts[0]
                                    val rel = parts[1]
                                    File(webViewDirForSuffix(ctx, suffix), rel)
                                }
                            }
                            else -> null
                        }

                        if (target != null) {
                            target.parentFile?.mkdirs()
                            target.outputStream().use { out ->
                                val buf = ByteArray(16 * 1024)
                                var n: Int
                                while (zip.read(buf).also { n = it } > 0) {
                                    out.write(buf, 0, n)
                                    byteCount += n.toLong()
                                }
                            }
                            fileCount++
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: throw IllegalStateException("Cannot open input stream for Uri")

        return BackupStats(fileCount, byteCount)
    }

    private fun addFile(zip: ZipOutputStream, file: File, entryName: String): Int {
        zip.putNextEntry(ZipEntry(entryName))
        var bytes = 0L
        file.inputStream().use { ins ->
            val buf = ByteArray(16 * 1024)
            var n: Int
            while (ins.read(buf).also { n = it } > 0) {
                zip.write(buf, 0, n)
                bytes += n.toLong()
            }
        }
        zip.closeEntry()
        return 1
    }

    private fun addDir(zip: ZipOutputStream, dir: File, prefix: String): Int {
        var count = 0
        var bytes = 0L
        dir.walkTopDown().forEach { f ->
            if (f.isFile) {
                val rel = prefix + f.relativeTo(dir).path.replace("\\", "/")
                zip.putNextEntry(ZipEntry(rel))
                f.inputStream().use { ins ->
                    val buf = ByteArray(16 * 1024)
                    var n: Int
                    while (ins.read(buf).also { n = it } > 0) {
                        zip.write(buf, 0, n)
                        bytes += n.toLong()
                    }
                }
                zip.closeEntry()
                count++
            }
        }
        // return count but bytes is accumulated externally in exportAll; to keep simple, we ignore bytes here
        return count
    }
}