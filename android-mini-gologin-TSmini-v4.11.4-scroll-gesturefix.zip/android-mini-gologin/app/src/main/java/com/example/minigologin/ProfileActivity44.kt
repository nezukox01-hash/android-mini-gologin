package com.example.minigologin

class ProfileActivity44 : BaseProfileActivity()
