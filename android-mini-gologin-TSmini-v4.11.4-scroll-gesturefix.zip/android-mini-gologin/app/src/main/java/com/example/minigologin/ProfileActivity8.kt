package com.example.minigologin

class ProfileActivity8 : BaseProfileActivity()
