package com.example.minigologin

class ProfileActivity56 : BaseProfileActivity()
