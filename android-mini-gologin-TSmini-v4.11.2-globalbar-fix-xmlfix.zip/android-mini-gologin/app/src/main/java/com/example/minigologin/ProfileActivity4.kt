package com.example.minigologin

class ProfileActivity4 : BaseProfileActivity()
