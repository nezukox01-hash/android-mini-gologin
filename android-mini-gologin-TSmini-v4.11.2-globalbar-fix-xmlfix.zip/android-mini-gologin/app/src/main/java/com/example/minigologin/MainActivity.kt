package com.example.minigologin

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private val createBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            try {
                val stats = BackupManager.exportAll(this, uri)
                Toast.makeText(this, "Backup saved (${stats.files} files)", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Backup failed: ${'$'}{e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val pickRestoreLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val stats = BackupManager.importAll(this, uri)
                Toast.makeText(this, "Restore done (${stats.files} files). Please restart app.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Restore failed: ${'$'}{e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeStore.applySaved(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Top bar
        val topbar = findViewById<MaterialToolbar>(R.id.topbar)
        setSupportActionBar(topbar)

        // Global Settings Bar (applies to ALL profiles + tabs)
        val textOnlySwitch = findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.textOnlySwitch)
        val startPageBtn = findViewById<MaterialButton>(R.id.startPageBtn)

        fun refreshStartPageButton() {
            val mode = AppSettingsStore.getStartMode(this)
            val label = when (mode) {
                "duckduckgo" -> "Start: DuckDuckGo"
                "custom" -> {
                    val raw = AppSettingsStore.getCustomStartUrl(this).trim()
                    if (raw.isBlank()) "Start: Custom" else "Start: " + raw.take(24) + if (raw.length > 24) "…" else ""
                }
                else -> "Start: Google"
            }
            startPageBtn.text = label
        }

        textOnlySwitch.isChecked = AppSettingsStore.isTextOnlyEnabled(this)
        textOnlySwitch.setOnCheckedChangeListener { _, enabled ->
            AppSettingsStore.setTextOnlyEnabled(this, enabled)
            AppSettingsStore.broadcastTextOnlyChanged(this)
            Toast.makeText(
                this,
                if (enabled) "Text-only enabled (experimental)" else "Text-only disabled",
                Toast.LENGTH_SHORT
            ).show()
        }

        refreshStartPageButton()
        startPageBtn.setOnClickListener {
            val items = arrayOf("Google", "DuckDuckGo", "Custom URL…")
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Start page (global)")
                .setItems(items) { _, which ->
                    when (which) {
                        0 -> {
                            AppSettingsStore.setStartMode(this, "google")
                            AppSettingsStore.broadcastStartPageChanged(this)
                            refreshStartPageButton()
                        }
                        1 -> {
                            AppSettingsStore.setStartMode(this, "duckduckgo")
                            AppSettingsStore.broadcastStartPageChanged(this)
                            refreshStartPageButton()
                        }
                        else -> {
                            val input = android.widget.EditText(this)
                            input.hint = "example.com or https://example.com"
                            input.setText(AppSettingsStore.getCustomStartUrl(this))
                            input.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI

                            androidx.appcompat.app.AlertDialog.Builder(this)
                                .setTitle("Custom start page")
                                .setView(input)
                                .setPositiveButton("Save") { _, _ ->
                                    AppSettingsStore.setStartMode(this, "custom")
                                    AppSettingsStore.setCustomStartUrl(this, input.text?.toString() ?: "")
                                    AppSettingsStore.broadcastStartPageChanged(this)
                                    refreshStartPageButton()
                                }
                                .setNegativeButton("Cancel", null)
                                .show()
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        val urlInput = findViewById<TextInputEditText>(R.id.urlInput)
        val profileInput = findViewById<TextInputEditText>(R.id.profileInput)
        val pickBtn = findViewById<MaterialButton>(R.id.pickProfileBtn)
        val openBtn = findViewById<MaterialButton>(R.id.openBtn)
        val backupBtn = findViewById<MaterialButton>(R.id.backupBtn)
        val restoreBtn = findViewById<MaterialButton>(R.id.restoreBtn)

        if (urlInput.text.isNullOrBlank()) {
            urlInput.setText("https://m.facebook.com")
        }

        
pickBtn.setOnClickListener { _ ->
            showProfilePicker { picked ->
                profileInput.setText(picked.toString())
            }
        }

        openBtn.setOnClickListener { v ->
            val url = normalizeUrl(urlInput.text?.toString() ?: "")
            val n = profileInput.text?.toString()?.trim()?.toIntOrNull()
            val max = ProfileStore.getMaxProfiles(this)

            if (n == null || n !in 1..max) {
                Snackbar.make(v, "Profile number must be 1–$max", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cls = Class.forName("com.example.minigologin.ProfileActivity$n")
            val intent = Intent(this, cls).apply {
                putExtra("url", url)
                putExtra("profile_id", n)
            }
            startActivity(intent)
        }

        backupBtn.setOnClickListener {
            // Save to user-chosen location (Downloads etc.)
            createBackupLauncher.launch("TSmini-backup.zip")
        }

        restoreBtn.setOnClickListener {
            // Pick a backup zip and restore into app storage
            pickRestoreLauncher.launch(arrayOf("application/zip"))
        }

    }


    private fun normalizeUrl(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return "https://m.facebook.com"
        val lower = s.lowercase()
        return if (lower.startsWith("http://") || lower.startsWith("https://")) s
        else "https://$s"
    }

    private fun showProfilePicker(onPick: (Int) -> Unit) {
        val max = ProfileStore.getMaxProfiles(this)
        val names = (1..max).map { i -> ProfileStore.getName(this, i) }.toMutableList()
        names.add("➕ Add profile")
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Select profile")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == max) {
                    val newMax = ProfileStore.addOneProfile(this)
                    Snackbar.make(findViewById(android.R.id.content), "Added profile $newMax", Snackbar.LENGTH_SHORT).show()
                    showProfilePicker(onPick)
                } else {
                    onPick(which + 1)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
