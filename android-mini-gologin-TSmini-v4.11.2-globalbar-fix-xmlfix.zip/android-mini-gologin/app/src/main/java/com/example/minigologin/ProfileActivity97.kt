package com.example.minigologin

class ProfileActivity97 : BaseProfileActivity()
