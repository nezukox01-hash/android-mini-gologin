Mini GoLogin Pro (Learning) - Android v4

Changes:
- Global bookmarks shared across all profiles.
- Clear data for ONE profile (logout only that profile).
- Fixed reload to reload current page (web.reload()).
- Switching profiles opens that profile's main page (start URL).
- Added "App Home" action to go back to the main screen.
- Fixed overflow menu text visibility in light mode (removed dark-only toolbar overlay).
- Added theme toggle (Light/Dark/Follow system) stored in prefs.

Build:
- Works with GitHub Actions unzip + Gradle build.
