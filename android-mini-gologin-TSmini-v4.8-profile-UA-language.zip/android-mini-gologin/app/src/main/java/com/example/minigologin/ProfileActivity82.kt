package com.example.minigologin

class ProfileActivity82 : BaseProfileActivity()
