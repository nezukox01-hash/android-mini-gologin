package com.example.minigologin

class ProfileActivity64 : BaseProfileActivity()
