package com.example.minigologin

class ProfileActivity33 : BaseProfileActivity()
