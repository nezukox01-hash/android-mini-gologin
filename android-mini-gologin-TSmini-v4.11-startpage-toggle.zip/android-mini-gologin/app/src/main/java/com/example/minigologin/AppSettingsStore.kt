package com.example.minigologin

import android.content.Context
import android.content.Intent

/** App-wide settings (apply to all profiles/tabs). */
object AppSettingsStore {
    private const val PREFS = "app_settings"
    private const val KEY_TEXT_ONLY = "text_only"

    // Global start page (applies to new profiles + new tabs)
    private const val KEY_START_PAGE_MODE = "start_page_mode" // google | duck | custom
    private const val KEY_START_PAGE_CUSTOM_URL = "start_page_custom_url"

    const val ACTION_TEXT_ONLY_CHANGED = "com.example.minigologin.TEXT_ONLY_CHANGED"

    fun isTextOnlyEnabled(ctx: Context): Boolean {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_TEXT_ONLY, false)
    }

    fun setTextOnlyEnabled(ctx: Context, enabled: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_TEXT_ONLY, enabled)
            .apply()
    }

    fun broadcastTextOnlyChanged(ctx: Context) {
        ctx.sendBroadcast(Intent(ACTION_TEXT_ONLY_CHANGED))
    }

    fun getStartPageMode(ctx: Context): String {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_START_PAGE_MODE, "google") ?: "google"
    }

    /** Returns a fully-qualified URL (with https://) for the chosen start page. */
    fun getStartPageUrl(ctx: Context): String {
        return when (getStartPageMode(ctx)) {
            "duck" -> "https://duckduckgo.com"
            "custom" -> {
                val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString(KEY_START_PAGE_CUSTOM_URL, "") ?: ""
                val trimmed = raw.trim()
                if (trimmed.isEmpty()) "https://www.google.com" else normalizeUrl(trimmed)
            }
            else -> "https://www.google.com"
        }
    }

    fun setStartPage(ctx: Context, mode: String, customUrl: String?) {
        val editor = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_START_PAGE_MODE, mode)
        if (mode == "custom") editor.putString(KEY_START_PAGE_CUSTOM_URL, customUrl?.trim() ?: "")
        editor.apply()
    }

    private fun normalizeUrl(raw: String): String {
        val s = raw.trim()
        val lower = s.lowercase()
        return if (lower.startsWith("http://") || lower.startsWith("https://")) s else "https://$s"
    }
}
