package com.example.minigologin

class ProfileActivity41 : BaseProfileActivity()
