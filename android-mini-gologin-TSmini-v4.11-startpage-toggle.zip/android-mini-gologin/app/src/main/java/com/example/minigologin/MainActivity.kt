package com.example.minigologin

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private val createBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            try {
                val stats = BackupManager.exportAll(this, uri)
                Toast.makeText(this, "Backup saved (${stats.files} files)", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Backup failed: ${'$'}{e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val pickRestoreLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val stats = BackupManager.importAll(this, uri)
                Toast.makeText(this, "Restore done (${stats.files} files). Please restart app.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Restore failed: ${'$'}{e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeStore.applySaved(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Global toggle in the top bar (applies to ALL profiles + tabs)
        val topbar = findViewById<MaterialToolbar>(R.id.topbar)
        setSupportActionBar(topbar)
        topbar.inflateMenu(R.menu.main_topbar)
        val textOnlyItem = topbar.menu.findItem(R.id.action_text_only)
        textOnlyItem.isChecked = AppSettingsStore.isTextOnlyEnabled(this)
        topbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_text_only -> {
                    val enabled = !item.isChecked
                    item.isChecked = enabled
                    AppSettingsStore.setTextOnlyEnabled(this, enabled)
                    AppSettingsStore.broadcastTextOnlyChanged(this)
                    Toast.makeText(
                        this,
                        if (enabled) "Text-only enabled (experimental)" else "Text-only disabled",
                        Toast.LENGTH_SHORT
                    ).show()
                    true
                }
	            R.id.action_start_page -> {
	                showStartPageDialog(urlInput)
	                true
	            }
                else -> false
            }
        }

        val urlInput = findViewById<TextInputEditText>(R.id.urlInput)
        val profileInput = findViewById<TextInputEditText>(R.id.profileInput)
        val pickBtn = findViewById<MaterialButton>(R.id.pickProfileBtn)
        val openBtn = findViewById<MaterialButton>(R.id.openBtn)
        val backupBtn = findViewById<MaterialButton>(R.id.backupBtn)
        val restoreBtn = findViewById<MaterialButton>(R.id.restoreBtn)

	    if (urlInput.text.isNullOrBlank()) {
	        urlInput.setText(AppSettingsStore.getStartPageUrl(this))
	    }

        
pickBtn.setOnClickListener { _ ->
            showProfilePicker { picked ->
                profileInput.setText(picked.toString())
            }
        }

        openBtn.setOnClickListener { v ->
            val url = normalizeUrl(urlInput.text?.toString() ?: "")
            val n = profileInput.text?.toString()?.trim()?.toIntOrNull()
            val max = ProfileStore.getMaxProfiles(this)

            if (n == null || n !in 1..max) {
                Snackbar.make(v, "Profile number must be 1–$max", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cls = Class.forName("com.example.minigologin.ProfileActivity$n")
            val intent = Intent(this, cls).apply {
                putExtra("url", url)
                putExtra("profile_id", n)
            }
            startActivity(intent)
        }

        backupBtn.setOnClickListener {
            // Save to user-chosen location (Downloads etc.)
            createBackupLauncher.launch("TSmini-backup.zip")
        }

        restoreBtn.setOnClickListener {
            // Pick a backup zip and restore into app storage
            pickRestoreLauncher.launch(arrayOf("application/zip"))
        }

    }


    private fun normalizeUrl(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return AppSettingsStore.getStartPageUrl(this)
        val lower = s.lowercase()
        return if (lower.startsWith("http://") || lower.startsWith("https://")) s
        else "https://$s"
    }

    private fun showStartPageDialog(urlInput: TextInputEditText) {
        val modes = arrayOf("Google", "DuckDuckGo", "Custom URL")
        val keys = arrayOf("google", "duck", "custom")

        var selected = keys.indexOf(AppSettingsStore.getStartPageMode(this)).coerceAtLeast(0)

        val customInput = android.widget.EditText(this).apply {
            hint = "https://example.com"
            setSingleLine(true)
        }

        fun syncCustomEnabled() {
            val isCustom = keys[selected] == "custom"
            customInput.isEnabled = isCustom
            if (!isCustom) customInput.setText("")
        }
        syncCustomEnabled()

        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
            addView(android.widget.TextView(this@MainActivity).apply {
                text = "Default start page for new profiles and new tabs"
            })
            addView(android.view.View(this@MainActivity).apply {
                minimumHeight = (10 * resources.displayMetrics.density).toInt()
            })
            addView(customInput)
        }

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Start page")
            .setSingleChoiceItems(modes, selected) { _, which ->
                selected = which
                syncCustomEnabled()
            }
            .setView(container)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val mode = keys[selected]
                val custom = if (mode == "custom") customInput.text?.toString().orEmpty() else null
                AppSettingsStore.setStartPage(this, mode, custom)
                urlInput.setText(AppSettingsStore.getStartPageUrl(this))
                Toast.makeText(this, "Start page saved", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun showProfilePicker(onPick: (Int) -> Unit) {
        val max = ProfileStore.getMaxProfiles(this)
        val names = (1..max).map { i -> ProfileStore.getName(this, i) }.toMutableList()
        names.add("➕ Add profile")
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Select profile")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == max) {
                    val newMax = ProfileStore.addOneProfile(this)
                    Snackbar.make(findViewById(android.R.id.content), "Added profile $newMax", Snackbar.LENGTH_SHORT).show()
                    showProfilePicker(onPick)
                } else {
                    onPick(which + 1)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
