package com.example.minigologin

class ProfileActivity35 : BaseProfileActivity()
