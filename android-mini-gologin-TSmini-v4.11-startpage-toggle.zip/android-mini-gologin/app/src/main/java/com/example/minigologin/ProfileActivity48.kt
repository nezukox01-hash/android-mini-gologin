package com.example.minigologin

class ProfileActivity48 : BaseProfileActivity()
