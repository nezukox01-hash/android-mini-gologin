Mini GoLogin (Learning) - Android (WebView multi-process profiles)

What this project does:
- Provides 20 profile slots.
- Each profile opens in its own Android process (:p1..:p20).
- On Android 9+, each process calls WebView.setDataDirectorySuffix("pN")
  which isolates cookies/storage between profiles.

How to run:
1) Open this folder in Android Studio.
2) Let Gradle sync (it will download dependencies).
3) Run on a real device (Android 9+).

Limitations:
- This is NOT a full GoLogin/anti-detect browser.
- Fingerprint spoofing at the engine level is not implemented (learning scope).
