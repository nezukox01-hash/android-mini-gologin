package com.example.minigologin

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val urlInput = findViewById<TextInputEditText>(R.id.urlInput)
        val profileInput = findViewById<TextInputEditText>(R.id.profileInput)
        val openBtn = findViewById<MaterialButton>(R.id.openBtn)

        if (urlInput.text.isNullOrBlank()) {
            urlInput.setText("https://m.facebook.com")
        }

        openBtn.setOnClickListener { v ->
            val url = (urlInput.text?.toString()?.trim()).orEmpty().ifBlank { "https://m.facebook.com" }
            val n = profileInput.text?.toString()?.trim()?.toIntOrNull()

            if (n == null || n !in 1..20) {
                Snackbar.make(v, "Profile number must be 1–20", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cls = Class.forName("com.example.minigologin.ProfileActivity$n")
            val intent = Intent(this, cls).apply {
                putExtra("url", url)
                putExtra("profile", n)
            }
            startActivity(intent)
        }
    }
}
