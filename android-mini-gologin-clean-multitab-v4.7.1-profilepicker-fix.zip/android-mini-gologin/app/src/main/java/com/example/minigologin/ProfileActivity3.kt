package com.example.minigologin

class ProfileActivity3 : BaseProfileActivity()
