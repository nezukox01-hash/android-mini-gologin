package com.example.minigologin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class WebTabFragment : Fragment() {

    private var webView: WebView? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val ctx = requireContext()

        val swipeLayout = SwipeRefreshLayout(ctx)
        val wv = WebView(ctx)

        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true

        // Needed for alert(), confirm(), prompt()
        wv.webChromeClient = WebChromeClient()

        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                swipeLayout.isRefreshing = false
            }
        }

        swipeLayout.setOnRefreshListener { wv.reload() }
        swipeLayout.setOnChildScrollUpCallback { _, _ -> wv.scrollY > 0 }

        swipeLayout.addView(
            wv,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val url = arguments?.getString("url") ?: "https://www.google.com"
        wv.loadUrl(url)

        webView = wv
        return swipeLayout
    }

    override fun onDestroyView() {
        super.onDestroyView()
        webView = null
    }

    fun getWebViewOrNull(): WebView? = webView

    companion object {
        fun newInstance(url: String): WebTabFragment {
            val fragment = WebTabFragment()
            val args = Bundle()
            args.putString("url", url)
            fragment.arguments = args
            return fragment
        }
    }
}
