package com.example.minigologin

class ProfileActivity47 : BaseProfileActivity()
