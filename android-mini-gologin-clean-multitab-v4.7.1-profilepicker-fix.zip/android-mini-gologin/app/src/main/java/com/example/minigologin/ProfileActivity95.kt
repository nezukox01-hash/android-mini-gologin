package com.example.minigologin

class ProfileActivity95 : BaseProfileActivity()
