package com.example.minigologin

class ProfileActivity21 : BaseProfileActivity()
