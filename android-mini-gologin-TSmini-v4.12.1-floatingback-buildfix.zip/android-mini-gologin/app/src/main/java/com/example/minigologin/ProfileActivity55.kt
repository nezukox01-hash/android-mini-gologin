package com.example.minigologin

class ProfileActivity55 : BaseProfileActivity()
