package com.example.minigologin

class ProfileActivity45 : BaseProfileActivity()
