package com.example.minigologin

class ProfileActivity89 : BaseProfileActivity()
