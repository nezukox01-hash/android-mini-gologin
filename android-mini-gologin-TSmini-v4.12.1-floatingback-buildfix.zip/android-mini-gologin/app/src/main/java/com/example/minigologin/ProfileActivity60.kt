package com.example.minigologin

class ProfileActivity60 : BaseProfileActivity()
